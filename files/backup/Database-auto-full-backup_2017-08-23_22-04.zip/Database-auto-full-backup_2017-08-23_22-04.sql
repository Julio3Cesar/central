#
# TABLE STRUCTURE FOR: article_has_attachments
#

DROP TABLE IF EXISTS article_has_attachments;

CREATE TABLE `article_has_attachments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `article_id` bigint(20) DEFAULT '0',
  `filename` varchar(250) DEFAULT '0',
  `savename` varchar(250) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: clients
#

DROP TABLE IF EXISTS clients;

CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(140) DEFAULT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `email` varchar(180) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  `mobile` varchar(25) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `zipcode` varchar(30) NOT NULL,
  `userpic` varchar(150) NOT NULL DEFAULT 'no-pic.png',
  `city` varchar(45) DEFAULT NULL,
  `hashed_password` varchar(255) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `access` varchar(150) DEFAULT '0',
  `last_active` varchar(50) DEFAULT NULL,
  `last_login` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('29', '26', 'Rafael ', 'Bitencourt Palma', 'bitencourt.palma@hotmail.com', '', '(11) 99307-5767', '', '', 'no-pic.png', 'São Pualo', '3d7846418186741b8e858d36b2f88e6594c062733b92f2ebebbec8205e03f6d1455a354ab0baf07e580b304573924cd8d1e67699344eb0b64aadcae19eab03bf', '0', '14,12,13,107,15,17', '0', '1497642276');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('30', '28', 'Valdiva ', 'Batista Pereira', 'diva@divalingerie.com.br', '', '(11) 95895-6419', 'Rua Itrapoá', '04950-140', 'no-pic.png', 'São Paulo', '0d7bcce82dce80ecfa2fd9d0edf9ceff7d285e517127a1db8d075ee92e0674cd4d5e23c95ea41335d50687e65110154e88fc956b98b93c46f5391a3a6397e1cd', '0', '14,12,13,107,15,17', '1497642701', '1497642646');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('34', '32', 'teste 1', 'teste', 'teste@teste.com.br', '', '', 'teste', '04846030', 'no-pic.png', 'teste', '548bc962efae0574fa0cc5ffdcee0b5773a321b7f075f6be8bbfdf26a3ba6c63bbf2d298f84dd99e05ba686b7b5329c6a3fe5a0d3c2cf8758b63c689cf8f0920', '1', '14,12,13,17,', '0', '1497641728');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('35', '33', 'teste', 'teste', 'kaique.alves@locaweb.com.br', '', '', '', '', 'no-pic.png', '', '2a5c1c0e07331d1f1fa2204f42c12b0840452f2775621baa932f25002b62e0e3164cb9288723e98bd910a18b3e68ef447dec590f926fab9ec014529c10b04d00', '1', '14,12,13,107,15,17', '0', '1497642373');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('36', '34', 'teste', 'teste', 'kaique.alves@locaweb.com.br', '', '', '', '', 'no-pic.png', 'São paulo', '78fa06d9f262df98b6889ed3c53e4b54ecc6080880a0ba81ee40cd115a0c34f98be265b437ace4a3cedb4801679bb60c0cf44ec10026879d931a193f1124b81d', '1', '14,12,13,107,15,17', '0', '1498057375');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('39', '37', 'teste kaique', 'testeq', 'kaiquesp@hotmail.com', '', '', 'teste', '04864030', 'no-pic.png', 'São Paulo', '7fc23a7d0b38b2a4ce08c23784f0edc83b9302134d0d47f9a5dcaed12fdbf4de05b5631706c908bd8774e2646a95734516abf0b6ce952f411cc3a0a1a76e703e', '1', '14,12,13,107,17', '0', '1498074831');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('40', '38', 'Augusto', 'Thiago', 'ribeirot62@gmail.com', '', '11948585258', 'Rua Selma Kurtz 87', '04434010', 'no-pic.png', 'São Paulo', '750f86365adadc64c092c308ed48e0f93df860b80f636ce2c3d38bd9362031355ecf418eb0b0cdc0c035e98624a513bfa7408fa3683dc76915c1e493e8416852', '1', '14,12,13,17,', '0', '1499456379');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('41', '39', 'kaique', 'kaique', 'kaique@websitego.com.br', '', '', 'teste', '04864030', 'no-pic.png', 'são paulo', '12472d09c1644a306973451ea0b0e28a6d2546fb5439a8303c940f72fbed4815e921fa3f64afb556709f5e4411396a7e0ce85cb88590d56e7c12bc487db92c10', '1', '14,12,13,17,', '0', '1499985010');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('42', '40', 'Gerson', 'Silva do Nascimento', 'gerson.nascimento@locaweb.com.br', '1146446976', '11966263582', 'Rugiero Fedeli', '04963190', 'no-pic.png', 'São Paulo', '1b8d51f916ab065c28dc69690ea3d118fb273ae134d1aee1b3eee28f1b8deb0361fbb9af16d94f88b1cee8e028f0c51cff3eb1c94e62f86f5ccc6ada94623bc5', '0', '14,12,13,17,', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('43', '41', 'testenaoapagar', 'teste', 'kaiquesp@hotmail.com', '', '', '', '', 'no-pic.png', '', '52b45de91b53e9db87a79daa250f7dde3c8f5b5a104eb5b56ecfca8b79d1cc8bc1ca3cd8ce2b9baf112b346ed70bc8a223e7ccc3d03278f47a50f89e5a0f3bb1', '0', '14,12,13,107,15,17', '1503438819', '1503438807');


#
# TABLE STRUCTURE FOR: companies
#

DROP TABLE IF EXISTS companies;

CREATE TABLE `companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` int(11) NOT NULL,
  `name` varchar(140) DEFAULT NULL,
  `client_id` varchar(140) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  `mobile` varchar(25) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `zipcode` varchar(30) NOT NULL,
  `city` varchar(45) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `website` varchar(250) DEFAULT NULL,
  `country` varchar(250) DEFAULT NULL,
  `vat` varchar(250) DEFAULT NULL,
  `note` longtext,
  `province` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('26', '41002', 'Rafael Bitencourt Palma', '29', '(11) 99307-5767', '(11) 99307-5767', '', '', 'São Paulo', '0', 'montpiscinas.com.br', 'Brasil', '', 'Hospedagem de sites Basic: &lt;br&gt;Registro de domínio: montpiscinas.com.br&lt;br&gt;E-mail secundário: leandro_pate@hotmail.com', 'SP');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('28', '41004', 'Valdiva Batista Pereira', '30', '', '(11) 95895-6419', '', '04950-140', 'São Paulo', '0', 'divalingerie.com.br', 'Brasil', '', 'Registro de Domínio: divalingerie.com.br', 'SP');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('32', '41008', 'teste', '34', '', '', 'teste', '04846030', 'teste', '1', '', 'teste', '', NULL, '');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('33', '41009', 'teste', '35', '', '', '', '', '', '1', '', '', '', NULL, '');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('34', '41010', 'teste', '36', '', '', '', '', '', '1', '', '', '', NULL, '');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('37', '41013', 'Teste Kaique', '39', '', '', 'teste', '04864030', 'São Paulo', '1', '', 'Brasil', '', NULL, 'SP');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('38', '41014', 'Augusto', '40', '', '11948585258', 'Rua Selma Kurtz 87', '04434010', 'São Paulo', '1', 'uol.com.br', 'Brasil', '', NULL, 'São Paulo');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('39', '41015', 'kaique', '41', '', '', 'teste', '04864030', 'são paulo', '1', '', 'brasil', '', NULL, 'SP');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('40', '41016', 'Enloogs', '42', '1146446976', '11966263582', 'Rugiero Fedeli', '04963190', 'São Paulo', '0', 'enloogs.com.br', 'Brasil', '', NULL, 'São Paulo');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('41', '41017', 'Teste Não apagar', '43', '', '', '', '', '', '0', '', '', '', NULL, '');


#
# TABLE STRUCTURE FOR: core
#

DROP TABLE IF EXISTS core;

CREATE TABLE `core` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` char(10) NOT NULL DEFAULT '0',
  `domain` varchar(65) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `tax` varchar(5) DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `autobackup` int(11) DEFAULT NULL,
  `cronjob` int(11) DEFAULT NULL,
  `last_cronjob` int(11) DEFAULT NULL,
  `last_autobackup` int(11) DEFAULT NULL,
  `invoice_terms` mediumtext,
  `company_reference` int(6) DEFAULT NULL,
  `project_reference` int(6) DEFAULT NULL,
  `invoice_reference` int(6) DEFAULT NULL,
  `subscription_reference` int(6) DEFAULT NULL,
  `ticket_reference` int(10) DEFAULT NULL,
  `date_format` varchar(20) DEFAULT NULL,
  `date_time_format` varchar(20) DEFAULT NULL,
  `invoice_mail_subject` varchar(150) DEFAULT NULL,
  `pw_reset_mail_subject` varchar(150) DEFAULT NULL,
  `pw_reset_link_mail_subject` varchar(150) DEFAULT NULL,
  `credentials_mail_subject` varchar(150) DEFAULT NULL,
  `notification_mail_subject` varchar(150) DEFAULT NULL,
  `language` varchar(150) DEFAULT NULL,
  `invoice_address` varchar(200) DEFAULT NULL,
  `invoice_city` varchar(200) DEFAULT NULL,
  `invoice_contact` varchar(200) DEFAULT NULL,
  `invoice_tel` varchar(50) DEFAULT NULL,
  `subscription_mail_subject` varchar(250) DEFAULT NULL,
  `logo` varchar(150) DEFAULT NULL,
  `template` varchar(200) DEFAULT 'blueline',
  `paypal` varchar(5) DEFAULT '1',
  `paypal_currency` varchar(200) DEFAULT 'EUR',
  `paypal_account` varchar(200) DEFAULT '',
  `invoice_logo` varchar(150) DEFAULT 'assets/blueline/img/invoice_logo.png',
  `pc` varchar(150) DEFAULT NULL,
  `vat` varchar(150) DEFAULT NULL,
  `ticket_email` varchar(250) DEFAULT NULL,
  `ticket_default_owner` int(10) DEFAULT '1',
  `ticket_default_queue` int(10) DEFAULT '1',
  `ticket_default_type` int(10) DEFAULT '1',
  `ticket_default_status` varchar(200) DEFAULT 'new',
  `ticket_config_host` varchar(250) DEFAULT NULL,
  `ticket_config_login` varchar(250) DEFAULT NULL,
  `ticket_config_pass` varchar(250) DEFAULT NULL,
  `ticket_config_port` varchar(250) DEFAULT NULL,
  `ticket_config_ssl` varchar(250) DEFAULT NULL,
  `ticket_config_email` varchar(250) DEFAULT NULL,
  `ticket_config_flags` varchar(250) DEFAULT '/notls',
  `ticket_config_search` varchar(250) DEFAULT 'UNSEEN',
  `ticket_config_timestamp` int(11) DEFAULT '0',
  `ticket_config_mailbox` varchar(250) DEFAULT NULL,
  `ticket_config_delete` int(11) DEFAULT '0',
  `ticket_config_active` int(11) DEFAULT '0',
  `ticket_config_imap` int(11) DEFAULT '1',
  `stripe` int(11) DEFAULT '0',
  `stripe_key` varchar(250) DEFAULT NULL,
  `stripe_p_key` varchar(255) DEFAULT '',
  `stripe_currency` varchar(255) DEFAULT 'USD',
  `bank_transfer` int(11) DEFAULT '0',
  `bank_transfer_text` longtext NOT NULL,
  `estimate_terms` longtext NOT NULL,
  `estimate_prefix` varchar(250) DEFAULT 'EST',
  `estimate_pdf_template` varchar(250) DEFAULT 'templates/estimate/blueline',
  `invoice_pdf_template` varchar(250) DEFAULT 'templates/invoice/blueline',
  `second_tax` varchar(5) DEFAULT '',
  `estimate_mail_subject` varchar(255) DEFAULT 'New Estimate #{estimate_id}',
  `money_format` int(20) unsigned NOT NULL DEFAULT '1',
  `money_currency_position` int(20) unsigned NOT NULL DEFAULT '1',
  `pdf_font` varchar(255) DEFAULT 'NotoSans',
  `pdf_path` int(10) unsigned NOT NULL DEFAULT '1',
  `registration` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO core (`id`, `version`, `domain`, `email`, `company`, `tax`, `currency`, `autobackup`, `cronjob`, `last_cronjob`, `last_autobackup`, `invoice_terms`, `company_reference`, `project_reference`, `invoice_reference`, `subscription_reference`, `ticket_reference`, `date_format`, `date_time_format`, `invoice_mail_subject`, `pw_reset_mail_subject`, `pw_reset_link_mail_subject`, `credentials_mail_subject`, `notification_mail_subject`, `language`, `invoice_address`, `invoice_city`, `invoice_contact`, `invoice_tel`, `subscription_mail_subject`, `logo`, `template`, `paypal`, `paypal_currency`, `paypal_account`, `invoice_logo`, `pc`, `vat`, `ticket_email`, `ticket_default_owner`, `ticket_default_queue`, `ticket_default_type`, `ticket_default_status`, `ticket_config_host`, `ticket_config_login`, `ticket_config_pass`, `ticket_config_port`, `ticket_config_ssl`, `ticket_config_email`, `ticket_config_flags`, `ticket_config_search`, `ticket_config_timestamp`, `ticket_config_mailbox`, `ticket_config_delete`, `ticket_config_active`, `ticket_config_imap`, `stripe`, `stripe_key`, `stripe_p_key`, `stripe_currency`, `bank_transfer`, `bank_transfer_text`, `estimate_terms`, `estimate_prefix`, `estimate_pdf_template`, `invoice_pdf_template`, `second_tax`, `estimate_mail_subject`, `money_format`, `money_currency_position`, `pdf_font`, `pdf_path`, `registration`) VALUES ('1', '2.3.5', 'http://central.websitego.com.br', 'contato@websitego.com.br', 'WebSiteGo', '0', 'R$', '1', '1', '1503536678', '0', '<div><div>Agradecemos por escolher a WebsiteGo. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '41018', '51007', '31017', '61004', '10003', 'd/m/Y', 'H:i', 'Nova fatura', 'Password Reset', 'Password Reset', 'Login Details', 'Notification', 'portuguese', 'rua joao morzilio', 'São Paulo', 'Kaique Alves', '11 975076059', 'New Subscription', 'files/media/websitego-logo.png', 'blueline', '1', 'BRL', 'kaiqueexp@gmail.com', 'files/media/websitego-logo1.png', '', '', NULL, '11', '1', '1', 'new', 'email-ssl.com.br', 'contato@websitego.com.br', 'Welcome100%', '993', '1', 'contato@websitego.com.br', '/novalidate-cert', 'UNSEEN', '0', 'INBOX', '0', '1', '1', '0', '', '', 'BRL', '0', '<span style=\"font-weight: bold;\">Ag</span>: 2921<div><span style=\"font-weight: bold;\">Cc</span>: 35972-1</div><div><span style=\"font-weight: bold;\">Kaique </span>Paes Alves</div><div><span style=\"font-weight: bold;\">CPF</span>: 40716300869</div><div><span style=\"font-weight: bold;\">Banco Itau</span></div>', '', 'EST', 'templates/estimate/blueline', 'templates/invoice/blueline', '', 'New Estimate #{estimate_id}', '1', '1', 'NotoSans', '1', '1');


#
# TABLE STRUCTURE FOR: custom_quotation_requests
#

DROP TABLE IF EXISTS custom_quotation_requests;

CREATE TABLE `custom_quotation_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form` longtext NOT NULL,
  `custom_quotation_id` int(11) unsigned NOT NULL,
  `date` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: custom_quotations
#

DROP TABLE IF EXISTS custom_quotations;

CREATE TABLE `custom_quotations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT '',
  `formcontent` longtext NOT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `created` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO custom_quotations (`id`, `name`, `formcontent`, `inactive`, `user_id`, `created`) VALUES ('3', 'Formulário de cotação', '{\"fields\":[{\"label\":\"Seu Nome\",\"field_type\":\"text\",\"required\":true,\"field_options\":{\"size\":\"small\"},\"cid\":\"c2\"},{\"label\":\"CPF/CNPJ\",\"field_type\":\"text\",\"required\":false,\"field_options\":{\"size\":\"small\"},\"cid\":\"c6\"},{\"label\":\"Telefone\",\"field_type\":\"text\",\"required\":true,\"field_options\":{\"size\":\"small\"},\"cid\":\"c10\"},{\"label\":\"Seu domínio\",\"field_type\":\"text\",\"required\":false,\"field_options\":{\"size\":\"small\",\"description\":\"ex: www.websitego.com.br\"},\"cid\":\"c16\"},{\"label\":\"E-mail\",\"field_type\":\"email\",\"required\":true,\"field_options\":{},\"cid\":\"c20\"},{\"label\":\"Tem loja física?\",\"field_type\":\"radio\",\"required\":true,\"field_options\":{\"options\":[{\"label\":\"Sim\",\"checked\":false},{\"label\":\"Não\",\"checked\":false}]},\"cid\":\"c24\"},{\"label\":\"Descreva qual serviço deseja\",\"field_type\":\"paragraph\",\"required\":true,\"field_options\":{\"size\":\"small\",\"description\":\"\"},\"cid\":\"c32\"}]}', '0', '9', '0');
INSERT INTO custom_quotations (`id`, `name`, `formcontent`, `inactive`, `user_id`, `created`) VALUES ('4', 'Contratação hospedagem', '{\"fields\":[{\"label\":\"Nome completo:\",\"field_type\":\"text\",\"required\":true,\"field_options\":{\"size\":\"small\"},\"cid\":\"c5\"},{\"label\":\"E-mail:\",\"field_type\":\"email\",\"required\":true,\"field_options\":{},\"cid\":\"c13\"},{\"label\":\"Telefone:\",\"field_type\":\"text\",\"required\":true,\"field_options\":{\"size\":\"small\"},\"cid\":\"c17\"},{\"label\":\"Hospedagem:\",\"field_type\":\"radio\",\"required\":true,\"field_options\":{\"options\":[{\"label\":\"Basic\",\"checked\":false},{\"label\":\"Plus\",\"checked\":true},{\"label\":\"Max\",\"checked\":false},{\"label\":\"Somente dúvidas\",\"checked\":false}]},\"cid\":\"c10\"}]}', '0', '10', '0');


#
# TABLE STRUCTURE FOR: expenses
#

DROP TABLE IF EXISTS expenses;

CREATE TABLE `expenses` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(250) DEFAULT '',
  `type` varchar(250) DEFAULT '',
  `category` varchar(250) DEFAULT '',
  `date` varchar(250) DEFAULT '',
  `currency` varchar(250) DEFAULT '',
  `value` float DEFAULT '0',
  `vat` varchar(250) DEFAULT '',
  `reference` varchar(250) DEFAULT '',
  `project_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rebill` int(20) unsigned NOT NULL DEFAULT '0',
  `invoice_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `attachment` varchar(250) DEFAULT '',
  `attachment_description` varchar(250) DEFAULT '',
  `recurring` varchar(250) DEFAULT '',
  `recurring_until` varchar(250) DEFAULT '',
  `user_id` int(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO expenses (`id`, `description`, `type`, `category`, `date`, `currency`, `value`, `vat`, `reference`, `project_id`, `rebill`, `invoice_id`, `attachment`, `attachment_description`, `recurring`, `recurring_until`, `user_id`) VALUES ('2', '3 Camisetas ', 'payment', 'Marketing', '2017-06-16', 'R$', '60', '', '', '0', '0', '0', '', '', '', '', '11');


#
# TABLE STRUCTURE FOR: invoice_has_items
#

DROP TABLE IF EXISTS invoice_has_items;

CREATE TABLE `invoice_has_items` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `amount` char(11) DEFAULT NULL,
  `description` mediumtext,
  `value` float DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `type` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;

INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('44', '29', '0', '1', '', '25', 'Hospedagem Basic - MySQL incluso - 5 Caixas postais', 'Hospedagem');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('45', '30', '17', '1', 'Plano de hospedagem', '25', 'Hospedagem Basic - MySQL incluso - 5 Caixas p', 'Hospedagem');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('46', '34', '17', '1', ' - MySQL incluso \n - 5 Caixas postais\n ', '25', 'Hospedagem Basic', 'Hospedagem de Sites ');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('47', '35', '17', '1', ' - MySQL incluso \n - 5 Caixas postais\n ', '25', 'Hospedagem Basic', 'Hospedagem de Sites ');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('51', '40', '0', '1', '', '33', 'Gggg', '');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('52', '41', '0', '1', '', '30.22', 'fsdfds', '');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('53', '34', '0', '1', '', '100', 'Site MontPiscinas 1/2', 'Desenvolvimento de sites');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('54', '35', '0', '1', '', '100', 'Site - monpiscinas 2x2', '');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('55', '35', '0', '1', 'Adição de Chat Online - TomTicket', '10', 'Chat - Website', '');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('56', '36', '17', '1', ' - MySQL incluso \n - 5 Caixas postais\n ', '25', 'Hospedagem Basic', 'Hospedagem de Sites ');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('57', '36', '20', '1', '- Chat Online - Hospedagem', '10', 'Chat Online', 'Site');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('58', '37', '0', '1', '', '1', 'teste', '');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('59', '38', '0', '1', '', '35', 'Hospedagem Basic - MySQL incluso - 5 Caixas postais', '');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('60', '38', '0', '1', '', '100', 'Desenvolvimento de sites', '');


#
# TABLE STRUCTURE FOR: invoices
#

DROP TABLE IF EXISTS invoices;

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` int(11) DEFAULT NULL,
  `company_id` int(11) NOT NULL,
  `status` varchar(50) DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `issue_date` varchar(20) DEFAULT NULL,
  `due_date` varchar(20) DEFAULT NULL,
  `sent_date` varchar(20) DEFAULT NULL,
  `paid_date` varchar(20) DEFAULT NULL,
  `terms` mediumtext,
  `discount` varchar(50) DEFAULT '0',
  `subscription_id` varchar(50) DEFAULT '0',
  `project_id` int(11) DEFAULT '0',
  `tax` varchar(255) DEFAULT '',
  `estimate` int(11) DEFAULT '0',
  `estimate_status` varchar(255) DEFAULT '0',
  `estimate_accepted_date` varchar(255) DEFAULT '0',
  `estimate_sent` varchar(255) DEFAULT '0',
  `sum` float DEFAULT '0',
  `second_tax` varchar(5) DEFAULT '',
  `estimate_reference` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('29', '31001', '26', 'Paid', 'R$', '2017-06-06', '2017-06-10', NULL, '2017-06-14', 'Thank you for your business. We do expect payment within {due_date}, so please process this invoice within that time.', '', '0', '0', '0', '0', '0', '0', '0', '25', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('34', '31006', '26', 'Paid', 'R$', '2017-07-05', '2017-07-10', NULL, '2017-07-11', '<div><div>Agradecemos por escolher a WebsiteGo. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '1,00', '0', '16', '0', '0', '0', '0', '0', '124', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('35', '31013', '26', 'Paid', 'R$', '2017-08-05', '2017-08-10', NULL, '2017-08-15', '<div><div>Agradecemos por escolher a WebsiteGo. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '1,00', '0', '16', '0', '0', '0', '0', '0', '134', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('36', '31014', '26', 'Open', 'R$', '2017-09-05', '2017-09-10', NULL, NULL, '<div><div>Agradecemos por escolher a WebsiteGo. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '1.00', '0', '0', '0', '0', '0', '0', '0', '34', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('38', '31016', '26', 'Sent', 'R$', '2017-08-10', '2017-08-24', '2017-08-23', NULL, '<div><div>Agradecemos por escolher a WebsiteGo. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '13', '0', '0', '0', '0', '0', '0', '135', '', '');


#
# TABLE STRUCTURE FOR: items
#

DROP TABLE IF EXISTS items;

CREATE TABLE `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `value` float DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `description` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('17', 'Hospedagem Basic', '25', 'Hospedagem de Sites ', '0', ' - MySQL incluso \n - 5 Caixas postais\n ');
INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('18', 'Registro de domínio', '40', 'Anual', '0', '');
INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('19', 'Registro de domínio', '40', 'Anual', '1', 'divalingerie.com.br');
INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('20', 'Chat Online', '10', 'Site', '0', '- Chat Online - Hospedagem');


#
# TABLE STRUCTURE FOR: messages
#

DROP TABLE IF EXISTS messages;

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT '0',
  `media_id` int(11) DEFAULT '0',
  `from` varchar(120) DEFAULT NULL,
  `text` text,
  `datetime` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: migrations
#

DROP TABLE IF EXISTS migrations;

CREATE TABLE `migrations` (
  `version` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: modules
#

DROP TABLE IF EXISTS modules;

CREATE TABLE `modules` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT '0',
  `link` varchar(250) DEFAULT '0',
  `type` varchar(250) DEFAULT '0',
  `icon` varchar(150) DEFAULT NULL,
  `sort` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8;

INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('1', 'Dashboard', 'dashboard', 'main', 'icon-th', '1');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('2', 'Messages', 'messages', 'main', 'icon-inbox', '2');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('3', 'Projects', 'projects', 'main', 'icon-briefcase', '3');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('4', 'Clients', 'clients', 'main', 'icon-user', '4');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('5', 'Invoices', 'invoices', 'main', 'icon-list-alt', '5');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('6', 'Items', 'items', 'main', 'icon-file', '7');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('7', 'Quotations', 'quotations', 'main', 'icon-list-alt', '8');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('8', 'Subscriptions', 'subscriptions', 'main', 'icon-calendar', '6');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('9', 'Settings', 'settings', 'main', 'icon-cog', '20');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('10', 'QuickAccess', 'quickaccess', 'widget', NULL, '50');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('11', 'User Online', 'useronline', 'widget', NULL, '51');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('12', 'Projects', 'cprojects', 'client', 'icon-briefcase', '2');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('13', 'Invoices', 'cinvoices', 'client', 'icon-list-alt', '3');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('14', 'Messages', 'cmessages', 'client', 'icon-inbox', '1');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('15', 'Subscriptions', 'csubscriptions', 'client', 'icon-calendar', '4');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('16', 'Tickets', 'tickets', 'main', 'icon-tag', '8');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('17', 'Tickets', 'ctickets', 'client', 'icon-tag', '4');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('18', 'Estimates', 'estimates', 'main', 'fa-files-o', '5');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('19', 'Expenses', 'expenses', 'main', 'fa-money', '5');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('107', 'Estimates', 'cestimates', 'client', 'fa-files-o', '3');


#
# TABLE STRUCTURE FOR: privatemessages
#

DROP TABLE IF EXISTS privatemessages;

CREATE TABLE `privatemessages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(150) NOT NULL,
  `sender` varchar(250) NOT NULL,
  `recipient` varchar(250) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text,
  `time` varchar(100) NOT NULL,
  `conversation` varchar(32) DEFAULT NULL,
  `deleted` int(11) DEFAULT '0',
  `attachment` varchar(255) DEFAULT '',
  `attachment_link` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=139 DEFAULT CHARSET=utf8;

INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('127', 'Replied', 'u10', 'u11', 'Potencial Cliente', '<p>Boa tarde</p><p>Ligar para o cliente&nbsp;<span style=\"font-weight: bold;\">Roberto </span>do número&nbsp;<span style=\"text-decoration-line: underline;\">+55 11 94715-0373</span> pois ele deseja criar uma loja virtual com nós.</p><p>Verificar com o cliente como ele quer o site e preencher o formulário:</p><p>► https://gerenciador.websitego.com.br/quotation/qid/3</p><p>Att</p>', '2017-06-19 13:33', '0b85a8a2282450915512c88cf3c5b10e', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('128', 'New', 'u10', 'u12', 'Potencial Cliente', '<p>Boa tarde</p><p>Ligar para o cliente&nbsp;<span style=\"font-weight: bold;\">Roberto&nbsp;</span>do número&nbsp;<span style=\"text-decoration-line: underline;\">+55 11 94715-0373</span>&nbsp;pois ele deseja criar uma loja virtual com nós.</p><p>Verificar com o cliente como ele quer o site e preencher o formulário:</p><p>► https://gerenciador.websitego.com.br/quotation/qid/3</p><p>Att</p>', '2017-06-19 13:33', '8b7c6df9c467aa5615dfdc98dd4580b2', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('129', 'Read', 'u11', 'u10', 'Potencial Cliente', '<p>Liguei para o cliente, ficamos de combinar via Whats app e marcar um encontro.</p><p>Att.</p>', '2017-06-20 12:09', '0b85a8a2282450915512c88cf3c5b10e', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('130', 'New', 'u11', 'c30', 'Renovar Conta no Iluria', '<p>Olá, Valdiva Batista Pereira.</p><p>Sua Loja virtual está <span style=\"font-weight: bold; color: rgb(255, 0, 0);\">Desativada</span> devido a pendência com a Iluria.</p><p>Acesse:&nbsp;http://admin.iluria.com/public/login.jsp</p><p><span style=\"font-weight: bold;\">Login:</span> diva@divalingerie.com.br</p><p><span style=\"font-weight: bold;\">Senha:</span> Senai115</p><p>E renove a sua assinatura pelo tempo que quiser.</p><p>Dúvidas estou a disposição.</p><p><br></p>', '2017-06-20 12:59', 'b3b433728ede238858f5c47874305c3f', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('131', 'New', 'u11', 'u17', 'Comprar camiseta', '<p>Bom dia Victor.</p><p>Precisamos que realize a comprar uma <span style=\"font-weight: bold;\">Camiseta Polo&nbsp;</span>cor&nbsp;<span style=\"font-weight: bold;\">Preta</span></p><p>Do seu tamanho&nbsp;sem estampa toda lisa, para a produção da camiseta bordada, segue uma de exemplo em anexo.</p><p>Att.</p>', '2017-06-20 13:06', 'a3825ca1541a58aa03a359c18d9d1aed', '0', 'camiseta.jpg', '133c8eca1b29c0eb7abf54d3707bdbd7.jpg');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('132', 'Read', 'u10', 'c39', 'teste', 'teste', '2017-06-21 16:28', '545bb5e96eaa416e2c6193098024019c', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('133', 'Replied', 'u11', 'u10', 'Novo Template de site', '<p><dl class=\"plan-info-list\" style=\"border: 0px; margin: 2px; padding: 5px 5px 0px; font-size: 11px; outline: none; clear: both; color: rgb(0, 0, 0); font-family: Verdana, Helvetica, sans-serif; background-color: rgb(247, 247, 247);\"><dd style=\"border: 0px; margin-top: 5px; margin-right: 0px; margin-bottom: 5px; padding: 1px 1px 1px 10px; outline: none; vertical-align: top; display: inline-block; line-height: 15px; font-weight: bold; width: 568px;\">hm8227</dd></dl><hr style=\"height: 2px; background: url(&quot;/assets/lines-285073b2e777b4f8d75e8491abece55b.png&quot;) repeat-x rgb(247, 247, 247); border-top: 0px; margin: 0px; padding: 0px; font-size: 11px; outline: none; color: rgb(0, 0, 0); font-family: Verdana, Helvetica, sans-serif;\"><dl class=\"plan-info-list\" style=\"border: 0px; margin: 2px; padding: 5px 5px 0px; font-size: 11px; outline: none; clear: both; color: rgb(0, 0, 0); font-family: Verdana, Helvetica, sans-serif; background-color: rgb(247, 247, 247);\"><dd style=\"border: 0px; margin-top: 5px; margin-right: 0px; margin-bottom: 5px; padding: 1px 1px 1px 10px; outline: none; vertical-align: top; display: inline-block; line-height: 15px; font-weight: bold; width: 568px;\">freeair1</dd></dl></p><p><dl class=\"plan-info-list\" style=\"border: 0px; margin: 2px; padding: 5px 5px 0px; font-size: 11px; outline: none; clear: both; color: rgb(0, 0, 0); font-family: Verdana, Helvetica, sans-serif; background-color: rgb(247, 247, 247);\"><dd style=\"border: 0px; margin-top: 5px; margin-right: 0px; margin-bottom: 5px; padding: 1px 1px 1px 10px; outline: none; vertical-align: top; display: inline-block; line-height: 15px; font-weight: bold; width: 568px;\">Achei esse Template Interessante.<br></dd></dl></p><p><dl class=\"plan-info-list\" style=\"border: 0px; margin: 2px; padding: 5px 5px 0px; font-size: 11px; outline: none; clear: both; color: rgb(0, 0, 0); font-family: Verdana, Helvetica, sans-serif; background-color: rgb(247, 247, 247);\"><dd style=\"border: 0px; margin-top: 5px; margin-right: 0px; margin-bottom: 5px; padding: 1px 1px 1px 10px; outline: none; vertical-align: top; display: inline-block; line-height: 15px; font-weight: bold; width: 568px;\"><br></dd></dl></p>', '2017-06-25 17:53', 'c9a20460a8aa49eeebb4b3c6024e2165', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('134', 'Read', 'u10', 'u11', 'Novo Template de site', '<p>Pode deixar que amanhã eu vou ver.</p><p>Mais pra ajudar passa o domínio aí.</p>', '2017-06-25 21:57', 'c9a20460a8aa49eeebb4b3c6024e2165', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('135', 'Read', 'u11', 'u10', 'Dados de acesso montpsicinas', '<p style=\"margin-bottom: 10px; line-height: 22px;\">Boa Tarde Kaique, segue os dados.</p><p style=\"margin-bottom: 10px; line-height: 22px;\"><span style=\"background-color: yellow;\">FTP:</span></p><table class=\"tableList\" id=\"table_ftp_details\" style=\"background-color: rgb(255, 255, 255);\"><tbody><tr><td class=\"span7 noBorderRight txtLeft\"><span style=\"font-weight: 700;\">Host de FTP:&nbsp;</span><a href=\"ftp://montpiscinas1@ftp.montpiscinas.provisorio.ws/\" tabindex=\"3\" target=\"_blank\" title=\"ftp.montpiscinas.provisorio.ws\" data-ga-goal=\"Host de FTP\" data-ga-result=\"Nova Janela (Protocolo FTP - ftp://)\" data-ga-context=\"FTP\" style=\"color: rgb(68, 68, 68); line-height: 18px;\">ftp.montpiscinas.provisorio.ws</a></td><td class=\"span3\"></td></tr><tr><td class=\"span7 noBorderRight txtLeft\"><span style=\"font-weight: 700;\">Usuário de FTP:&nbsp;</span>montpiscinas1</td><td class=\"span3\"></td></tr><tr><td class=\"span7 noBorderRight txtLeft\"><p style=\"margin-bottom: 10px; line-height: 22px;\"><span style=\"font-weight: 700;\">Senha de FTP:&nbsp;</span>Senai115 &nbsp; &nbsp; &nbsp;&nbsp;</p><p style=\"margin-bottom: 10px; line-height: 22px;\"><br></p><p style=\"margin-bottom: 10px; line-height: 22px;\"><span style=\"background-color: yellow;\">BANCO:</span></p><p style=\"margin-bottom: 10px; line-height: 22px;\"><span style=\"font-weight: bold;\">Usuário:&nbsp;</span>montpiscinas02</p><p style=\"margin-bottom: 10px; line-height: 22px;\"><span style=\"background-color: transparent; font-weight: bold;\">Servidor:</span><span style=\"background-color: transparent;\">&nbsp;</span><span style=\"background-color: transparent;\">montpiscinas02.mysql.dbaas.com.br</span></p><p style=\"margin-bottom: 10px; line-height: 22px;\"><span style=\"font-size: 14px; font-weight: bold;\">Senha:</span><span style=\"font-size: 14px;\">&nbsp;Wsgo@1020</span></p><p style=\"margin-bottom: 10px; line-height: 22px;\"><span style=\"font-size: 14px;\"><br></span></p><p style=\"margin-bottom: 10px; line-height: 22px;\"><span style=\"font-size: 14px;\"><br></span></p><p style=\"margin-bottom: 10px; line-height: 22px;\"><span style=\"font-size: 14px;\">Te</span><span style=\"font-size: 14px;\">mplate do site:&nbsp;freeair.com.br</span></p><p style=\"margin-bottom: 10px; line-height: 22px;\"><span style=\"font-size: 14px;\">Servidor:&nbsp;hm8227</span></p><p style=\"margin-bottom: 10px; line-height: 22px;\"><span style=\"font-size: 14px;\">FTP:&nbsp;freeair1&nbsp;</span></p></td></tr></tbody></table>', '2017-07-03 16:27', '63500c6e5d9f304acaa1a5552e9816a7', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('136', 'Replied', 'u10', 'u11', 'Migração do domínio e email', '<p>A migração do site montpiscinas.com.br foi concluída e os emails transferidos, já pode dar início na criação do conteúdo no site.</p><p>Para acessar o site use o link direto: montpiscinas.com.br/index.php</p><p>Att</p>', '2017-07-05 21:18', '9f0a678f65680a7c1559bcab956973e9', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('137', 'Replied', 'u11', 'u10', 'Migração do domínio e email', '<p>Sensacional.</p><p>Vamos concluir agora !!! </p><p><br></p><p>Vou seguir respondendo o chamado do cliente agora.</p>', '2017-07-05 22:31', '9f0a678f65680a7c1559bcab956973e9', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('138', 'Read', 'u10', 'u11', 'Migração do domínio e email', 'Eu já respondi kkkkk', '2017-07-05 23:09', '9f0a678f65680a7c1559bcab956973e9', '0', '', '');


#
# TABLE STRUCTURE FOR: project_has_activities
#

DROP TABLE IF EXISTS project_has_activities;

CREATE TABLE `project_has_activities` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `project_id` bigint(20) DEFAULT '0',
  `user_id` bigint(20) DEFAULT '0',
  `client_id` bigint(20) DEFAULT '0',
  `datetime` varchar(250) DEFAULT '0',
  `subject` varchar(250) DEFAULT '0',
  `message` longtext,
  `type` varchar(250) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('2', '15', '10', '0', '1497973333', 'file de mídia foi adicionado', '<b>Kaique Alves</b> carregado Template', 'media');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('3', '16', '11', '0', '1498573116', 'file de mídia foi adicionado', '<b>Thiago Pimentel</b> carregado Mídia para a criação do site - montpiscinas.com.br', 'media');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('4', '16', '11', '0', '1498656469', 'file de mídia foi adicionado', '<b>Thiago Pimentel</b> carregado Descrição dos Produtos', 'media');


#
# TABLE STRUCTURE FOR: project_has_files
#

DROP TABLE IF EXISTS project_has_files;

CREATE TABLE `project_has_files` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) DEFAULT '0',
  `user_id` int(10) DEFAULT '0',
  `client_id` int(10) DEFAULT '0',
  `type` varchar(80) DEFAULT '0',
  `name` varchar(120) DEFAULT '0',
  `filename` varchar(150) DEFAULT '0',
  `description` text,
  `savename` varchar(200) DEFAULT '0',
  `phase` varchar(100) DEFAULT '0',
  `date` varchar(50) DEFAULT '0',
  `download_counter` int(10) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

INSERT INTO project_has_files (`id`, `project_id`, `user_id`, `client_id`, `type`, `name`, `filename`, `description`, `savename`, `phase`, `date`, `download_counter`) VALUES ('30', '15', '10', '0', 'application/zip', 'Template', 'templatewebsitego.zip', 'template', 'c9a1d4621f05b689d6e372689c87a104.zip', 'Planning', '2017-06-20 12:41', '1');
INSERT INTO project_has_files (`id`, `project_id`, `user_id`, `client_id`, `type`, `name`, `filename`, `description`, `savename`, `phase`, `date`, `download_counter`) VALUES ('31', '16', '11', '0', 'application/x-7z-compressed', 'Mídia para a criação do site - montpiscinas.com.br', 'IMAGEM_DOS_PRODTOS_COMPLETO.7z', 'Imagens fotos, Logos etc.', '351eaa255beddc6b83ef70428006af60.7z', ' Desenvolvimento', '2017-06-28 10:27', '3');
INSERT INTO project_has_files (`id`, `project_id`, `user_id`, `client_id`, `type`, `name`, `filename`, `description`, `savename`, `phase`, `date`, `download_counter`) VALUES ('32', '16', '11', '0', 'text/plain', 'Descrição dos Produtos', 'Descrição_de_produtos.txt', 'montpiscinas.com.br', 'e44742a25dc22947017ca42bb7bb016e.txt', ' Desenvolvimento', '2017-06-28 10:26', '4');


#
# TABLE STRUCTURE FOR: project_has_invoices
#

DROP TABLE IF EXISTS project_has_invoices;

CREATE TABLE `project_has_invoices` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `project_id` bigint(20) DEFAULT '0',
  `invoice_id` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: project_has_tasks
#

DROP TABLE IF EXISTS project_has_tasks;

CREATE TABLE `project_has_tasks` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) DEFAULT '0',
  `name` varchar(250) DEFAULT '0',
  `user_id` int(10) DEFAULT '0',
  `status` varchar(50) DEFAULT '0',
  `public` int(10) DEFAULT '0',
  `datetime` int(11) DEFAULT NULL,
  `due_date` varchar(250) DEFAULT NULL,
  `description` text,
  `value` int(11) DEFAULT '0',
  `priority` smallint(6) DEFAULT '0',
  `time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8;

INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `value`, `priority`, `time`) VALUES ('47', '15', 'Layout', '10', 'done', '0', NULL, '2017-06-21', '', '0', '2', '0');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `value`, `priority`, `time`) VALUES ('48', '15', 'Página Home', '10', 'done', '0', NULL, '2017-07-31', '', '0', '2', '0');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `value`, `priority`, `time`) VALUES ('49', '15', 'Página Serviços', '10', 'done', '0', NULL, '2017-07-31', '<p><br></p>', '0', '2', '0');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `value`, `priority`, `time`) VALUES ('50', '15', 'Página Contato', '10', 'done', '0', NULL, '2017-07-31', '', '0', '2', '0');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `value`, `priority`, `time`) VALUES ('51', '16', 'Migração de Plataforma Windows/Linux', '11', 'done', '1', NULL, '2017-06-27', '<p><br></p>', '0', '3', '0');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `value`, `priority`, `time`) VALUES ('52', '16', 'Ajustar Hospedagem', '11', 'done', '1', NULL, '2017-06-28', '<p>Ajustar a Hospedagem como:</p><p>Memória </p><p>Versão de PHP</p><p>Entre outros.</p><p><br></p><p>Ajustado: http://montpiscinas.provisorio.ws/info.php</p>', '0', '2', '0');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `value`, `priority`, `time`) VALUES ('55', '16', 'Desenv Home', '10', 'done', '1', NULL, '', '<p><br><br></p>', '0', '2', '0');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `value`, `priority`, `time`) VALUES ('56', '16', 'Desenv Produtos', '10', 'done', '1', NULL, '', '<p><br><br></p>', '0', '2', '0');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `value`, `priority`, `time`) VALUES ('57', '16', 'Desenv Contato', '10', 'done', '1', NULL, '', '<p><br><br></p>', '0', '2', '0');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `value`, `priority`, `time`) VALUES ('58', '16', 'Testes Finais - Aguardando resposta do cliente.', '11', 'done', '1', NULL, '', '<p>Testes de Bugs, imagens e funcionalidade do site.</p><p>Apresentação ao cliente e feedback.</p><p>Aguardando resposta do cliente.<br></p>', '0', '2', '0');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `value`, `priority`, `time`) VALUES ('59', '16', 'Migração de email', '10', 'done', '1', NULL, '', '', '0', '2', '0');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `value`, `priority`, `time`) VALUES ('60', '15', 'Página Portfolio', '10', 'done', '0', NULL, '2017-07-31', '', '0', '2', '0');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `value`, `priority`, `time`) VALUES ('61', '15', 'Testes do site Websitego', '10', 'done', '0', NULL, '2017-07-31', '', '0', '3', '0');
INSERT INTO project_has_tasks (`id`, `project_id`, `name`, `user_id`, `status`, `public`, `datetime`, `due_date`, `description`, `value`, `priority`, `time`) VALUES ('65', '15', 'Correções finais - websitego', '10', 'open', '0', NULL, '', 'Enviei um e-mail para o seu e-mail kaique@websitego.com.br com os prints e correções.', '0', '2', '0');


#
# TABLE STRUCTURE FOR: project_has_workers
#

DROP TABLE IF EXISTS project_has_workers;

CREATE TABLE `project_has_workers` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('41', '11', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('42', '12', '15');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('43', '11', '11');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('44', '11', '12');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('45', '11', '14');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('46', '13', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('47', '14', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('49', '14', '11');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('50', '14', '14');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('51', '14', '16');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('52', '15', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('53', '15', '11');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('54', '15', '14');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('55', '16', '11');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('56', '16', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('57', '16', '12');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('58', '16', '14');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('59', '16', '17');


#
# TABLE STRUCTURE FOR: projects
#

DROP TABLE IF EXISTS projects;

CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` int(11) DEFAULT NULL,
  `name` varchar(65) DEFAULT NULL,
  `description` text,
  `start` varchar(20) DEFAULT NULL,
  `end` varchar(20) DEFAULT NULL,
  `progress` decimal(3,0) DEFAULT NULL,
  `phases` varchar(150) DEFAULT NULL,
  `tracking` int(11) DEFAULT NULL,
  `time_spent` int(11) DEFAULT NULL,
  `datetime` int(11) DEFAULT NULL,
  `sticky` enum('1','0') DEFAULT '0',
  `category` varchar(150) DEFAULT NULL,
  `company_id` int(11) NOT NULL,
  `note` longtext NOT NULL,
  `progress_calc` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_projects_clients1` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

INSERT INTO projects (`id`, `reference`, `name`, `description`, `start`, `end`, `progress`, `phases`, `tracking`, `time_spent`, `datetime`, `sticky`, `category`, `company_id`, `note`, `progress_calc`) VALUES ('15', '51005', 'Novo site Websitego', '', '2017-06-20', '2017-07-31', '86', 'Planning, Developing, Testing', '0', '12', '1497972396', '1', 'Websitego', '0', '', '1');
INSERT INTO projects (`id`, `reference`, `name`, `description`, `start`, `end`, `progress`, `phases`, `tracking`, `time_spent`, `datetime`, `sticky`, `category`, `company_id`, `note`, `progress_calc`) VALUES ('16', '51006', 'Site - monpiscinas', 'Projeto de Criação do Site montpiscinas.com.br\n', '2017-06-27', '2017-08-11', '100', 'Alteração de Plataforma, Desenvolvimento, Testes finais', NULL, '0', '1498572686', '1', 'Site institucional', '26', '', '1');


#
# TABLE STRUCTURE FOR: pw_reset
#

DROP TABLE IF EXISTS pw_reset;

CREATE TABLE `pw_reset` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `email` varchar(250) DEFAULT '0',
  `timestamp` varchar(250) DEFAULT '0',
  `token` varchar(250) DEFAULT '0',
  `user` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO pw_reset (`id`, `email`, `timestamp`, `token`, `user`) VALUES ('2', 'gerson.nascimento@locaweb.com.br', '1503010413', '2652009a03fe87c77564b461024c6c92', '0');
INSERT INTO pw_reset (`id`, `email`, `timestamp`, `token`, `user`) VALUES ('3', 'gerson.nascimento@locaweb.com.br', '1503010953', 'ef3d6cdee3fe56dc631ed09e8d264df7', '0');


#
# TABLE STRUCTURE FOR: queues
#

DROP TABLE IF EXISTS queues;

CREATE TABLE `queues` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT '0',
  `description` varchar(250) DEFAULT '0',
  `inactive` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO queues (`id`, `name`, `description`, `inactive`) VALUES ('1', 'Suporte', 'Suporte técnico', '0');
INSERT INTO queues (`id`, `name`, `description`, `inactive`) VALUES ('2', 'Vendas', 'Vendas', '0');
INSERT INTO queues (`id`, `name`, `description`, `inactive`) VALUES ('3', 'Cobrança', 'cobrança', '0');


#
# TABLE STRUCTURE FOR: quotations
#

DROP TABLE IF EXISTS quotations;

CREATE TABLE `quotations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `q1` varchar(50) DEFAULT NULL,
  `q2` varchar(50) DEFAULT NULL,
  `q3` varchar(50) DEFAULT NULL,
  `q4` varchar(150) DEFAULT NULL,
  `q5` text,
  `q6` varchar(50) DEFAULT NULL,
  `company` varchar(150) DEFAULT '-',
  `fullname` varchar(150) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(150) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `city` varchar(150) DEFAULT NULL,
  `zip` varchar(150) DEFAULT NULL,
  `country` varchar(150) DEFAULT NULL,
  `comment` text,
  `date` varchar(50) DEFAULT NULL,
  `status` varchar(150) DEFAULT '0',
  `user_id` int(50) DEFAULT '0',
  `replied` varchar(50) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: subscription_has_items
#

DROP TABLE IF EXISTS subscription_has_items;

CREATE TABLE `subscription_has_items` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `subscription_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `amount` char(11) DEFAULT NULL,
  `description` mediumtext,
  `value` float DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `type` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

INSERT INTO subscription_has_items (`id`, `subscription_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('1', '13', '0', '1', '', '35', 'Hospedagem Basic - MySQL incluso - 5 Caixas postais', '');
INSERT INTO subscription_has_items (`id`, `subscription_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('2', '13', '0', '1', '', '100', 'Desenvolvimento de sites', '');


#
# TABLE STRUCTURE FOR: subscriptions
#

DROP TABLE IF EXISTS subscriptions;

CREATE TABLE `subscriptions` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `reference` varchar(50) DEFAULT NULL,
  `company_id` int(10) DEFAULT '0',
  `status` varchar(50) DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `issue_date` varchar(20) DEFAULT NULL,
  `end_date` varchar(20) DEFAULT NULL,
  `frequency` varchar(20) DEFAULT NULL,
  `next_payment` varchar(20) DEFAULT NULL,
  `terms` mediumtext,
  `discount` varchar(50) DEFAULT '0',
  `subscribed` varchar(50) DEFAULT '0',
  `tax` varchar(255) DEFAULT '',
  `second_tax` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO subscriptions (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `end_date`, `frequency`, `next_payment`, `terms`, `discount`, `subscribed`, `tax`, `second_tax`) VALUES ('11', '61001', '28', 'Active', 'R$ 40,00', '2018-04-15', '2020-04-15', '+1 year', '2018-04-15', 'Thank you for your business. We do expect payment within {due_date}, so please process this invoice within that time.', '', '0', '0', '');
INSERT INTO subscriptions (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `end_date`, `frequency`, `next_payment`, `terms`, `discount`, `subscribed`, `tax`, `second_tax`) VALUES ('13', '61003', '26', 'Active', 'R$', '2017-08-10', '2018-12-10', '+1 month', '2017-09-10', '<div><div>Agradecemos por escolher a WebsiteGo. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '0', '');


#
# TABLE STRUCTURE FOR: templates
#

DROP TABLE IF EXISTS templates;

CREATE TABLE `templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(250) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `text` text NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ticket_has_articles
#

DROP TABLE IF EXISTS ticket_has_articles;

CREATE TABLE `ticket_has_articles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) DEFAULT NULL,
  `from` varchar(250) NOT NULL DEFAULT '0',
  `reply_to` varchar(250) DEFAULT '0',
  `to` varchar(250) DEFAULT '0',
  `cc` varchar(250) DEFAULT '0',
  `subject` varchar(250) DEFAULT '0',
  `message` text,
  `datetime` varchar(250) DEFAULT NULL,
  `internal` int(10) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8;

INSERT INTO ticket_has_articles (`id`, `ticket_id`, `from`, `reply_to`, `to`, `cc`, `subject`, `message`, `datetime`, `internal`) VALUES ('120', '52', 'Kaique Alves - kaiqueexp@gmail.com', 'kaiqueexp@gmail.com', 'teste@teste.com.br', '0', 'Fechar', 'teste', '1497641858', '0');
INSERT INTO ticket_has_articles (`id`, `ticket_id`, `from`, `reply_to`, `to`, `cc`, `subject`, `message`, `datetime`, `internal`) VALUES ('121', '52', 'teste teste - teste@teste.com.br', 'teste@teste.com.br', '0', '0', 'Nota 10', '10', '1497641883', '0');
INSERT INTO ticket_has_articles (`id`, `ticket_id`, `from`, `reply_to`, `to`, `cc`, `subject`, `message`, `datetime`, `internal`) VALUES ('122', '54', 'Thiago Pimentel - thiagopimentel@terra.com.br', 'thiagopimentel@terra.com.br', 'bitencourt.palma@hotmail.com', '0', 'Migração de Plataforma - montpiscinas.com.br', '<span style=\"color: rgb(68, 68, 68);\">Bom dia Rafael.</span><div><span style=\"color: rgb(68, 68, 68);\"><br></span></div><div><span style=\"color: rgb(68, 68, 68);\">A migração foi adiada por enquanto sem previsão de retorno.</span></div><div><span style=\"color: rgb(68, 68, 68);\"><br></span></div><div><span style=\"color: rgb(68, 68, 68);\">Pode seguir usando os e-mails normalmente.</span></div><div><span style=\"color: rgb(68, 68, 68);\"><br></span></div><div><span style=\"color: rgb(68, 68, 68);\">Qualquer novo update notificaremos neste protocolo.</span></div><div><span style=\"color: rgb(68, 68, 68);\"><br></span></div><div><p style=\"margin-bottom: 1em; color: rgb(68, 68, 68);\">Att.</p><p style=\"margin-bottom: 1em; color: rgb(68, 68, 68);\">WebsiteGO</p></div>', '1498576150', '0');
INSERT INTO ticket_has_articles (`id`, `ticket_id`, `from`, `reply_to`, `to`, `cc`, `subject`, `message`, `datetime`, `internal`) VALUES ('123', '54', 'Kaique Alves - kaiqueexp@gmail.com', 'kaiqueexp@gmail.com', 'bitencourt.palma@hotmail.com', '0', 'Migração de Plataforma - montpiscinas.com.br', 'Boa noite Rafael,<div><br></div><div>Realizamos a migração de seu site para a plataforma linux e todos os seus emails também foram migrados.</div><div><br></div><div>Informo que a migração já foi concluída e você já poderá utilizar os emails normalmente.</div><div><br></div><div>Atenciosamente</div><div><br></div><div>Websitego</div>', '1499300106', '0');


#
# TABLE STRUCTURE FOR: ticket_has_attachments
#

DROP TABLE IF EXISTS ticket_has_attachments;

CREATE TABLE `ticket_has_attachments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint(20) DEFAULT '0',
  `filename` varchar(250) DEFAULT '0',
  `savename` varchar(250) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: tickets
#

DROP TABLE IF EXISTS tickets;

CREATE TABLE `tickets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `from` varchar(250) DEFAULT '0',
  `reference` varchar(250) DEFAULT '0',
  `type_id` smallint(6) DEFAULT '1',
  `lock` smallint(6) DEFAULT '0',
  `subject` varchar(250) DEFAULT '0',
  `text` text,
  `status` varchar(50) DEFAULT '0',
  `client_id` int(11) DEFAULT '0',
  `company_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `escalation_time` int(11) DEFAULT '0',
  `priority` varchar(50) DEFAULT '0',
  `created` int(11) DEFAULT '0',
  `queue_id` int(11) DEFAULT '0',
  `updated` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;

INSERT INTO tickets (`id`, `from`, `reference`, `type_id`, `lock`, `subject`, `text`, `status`, `client_id`, `company_id`, `user_id`, `escalation_time`, `priority`, `created`, `queue_id`, `updated`) VALUES ('52', 'teste teste - teste@teste.com.br', '10000', '1', '0', 'teste', 'teste', 'closed', '34', '32', '11', '0', '0', '1497641778', '1', '1');
INSERT INTO tickets (`id`, `from`, `reference`, `type_id`, `lock`, `subject`, `text`, `status`, `client_id`, `company_id`, `user_id`, `escalation_time`, `priority`, `created`, `queue_id`, `updated`) VALUES ('53', 'teste kaique testeq - kaiquesp@hotmail.com', '10001', '1', '0', 'teste #01', 'teste', 'closed', '39', '37', '11', '0', '0', '1498074860', '1', '0');
INSERT INTO tickets (`id`, `from`, `reference`, `type_id`, `lock`, `subject`, `text`, `status`, `client_id`, `company_id`, `user_id`, `escalation_time`, `priority`, `created`, `queue_id`, `updated`) VALUES ('54', 'Rafael  Bitencourt Palma - bitencourt.palma@hotmail.com', '10002', '1', '0', 'Migração de Plataforma - montpiscinas.com.br', '<p style=\"margin-bottom: 1em;\">Bom dia Rafael.</p><p style=\"margin-bottom: 1em;\">A migração de Plataforma da sua Hospedagem está agendada para as 11:30&nbsp;</p><p style=\"margin-bottom: 1em;\">Com previsão para a correção até as 13:30</p><p style=\"margin-bottom: 1em;\">Qualquer novo update notificaremos neste protocolo.</p><p style=\"margin-bottom: 1em;\">Att.</p><p style=\"margin-bottom: 1em;\">WebsiteGO</p>', 'closed', '29', '26', '11', '0', '0', '1498571886', '1', '0');


#
# TABLE STRUCTURE FOR: types
#

DROP TABLE IF EXISTS types;

CREATE TABLE `types` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT '0',
  `description` varchar(250) DEFAULT '0',
  `inactive` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

INSERT INTO types (`id`, `name`, `description`, `inactive`) VALUES ('1', 'Requisiçao de serviço', 'Requisiçao de serviço', '0');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) DEFAULT NULL,
  `firstname` varchar(120) DEFAULT NULL,
  `lastname` varchar(120) DEFAULT NULL,
  `hashed_password` varchar(128) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `status` enum('active','inactive','deleted') DEFAULT NULL,
  `admin` enum('0','1') DEFAULT NULL,
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `userpic` varchar(250) DEFAULT 'no-pic.png',
  `title` varchar(150) NOT NULL,
  `access` varchar(150) NOT NULL DEFAULT '1,2',
  `last_active` varchar(50) DEFAULT NULL,
  `last_login` varchar(50) DEFAULT NULL,
  `queue` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('9', 'Admin', 'John', 'Doe', '785ea3511702420413df674029fe58d69692b3a0a571c0ba30177c7808db69ea22a8596b1cc5777403d4374dafaa708445a9926d6ead9a262e37cb0d78db1fe5', 'local@localhost', 'deleted', '1', '2013-01-01 00:00:00', 'no-pic.png', 'Administrator', '1,2,3,4,5,8,6,7,9,10,11,16,18,19', '1497889854', '1497475741', '0');
INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('10', 'kaique.alves', 'Kaique', 'Alves', '2de0452b2643fbe9e2ade14f51da5d000e06da7d49d63321b9ceae6ad60a085c86b8c70388a30199fa1303cac7b5e2357528f4584bc20a3401501dc4e279b433', 'kaiqueexp@gmail.com', 'active', '1', '2017-06-14 18:54:20', 'no-pic.png', 'Administrador', '1,2,3,4,5,18,19,8,6,7,16,9,10,11', '1503536678', '1503536035', '0');
INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('11', 'thiago.pimentel', 'Thiago', 'Pimentel', '47bd516a44f859d1a718c30d32353affa7368534168e803b37d07ec7f753b5e103e592bbbd3abcdf03e2a208028d4ef212a9bfdab8dc2a9ba9bdae5a964b4f92', 'thiagopimentel@terra.com.br', 'active', '0', '2017-06-14 20:59:28', '26ec99f64275588cad0e702fca6ce0d4.jpg', 'Gerente', '1,2,3,4,5,18,19,8,6,7,16,10,11', '1502938245', '1502938225', '0');
INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('12', 'leandro.julio', 'Leandro ', 'Julio', '36df42151fcb13359f29ce6c0cfdd3dc61c0221afb4745928deea1f41aa7e210ab1eb75bf9e40698029559cf80f37e441b1fb97680ac00734a8fe25f13e8b397', 'lecoideias@outlook.com', 'active', '0', '2017-06-14 21:00:17', 'no-pic.png', 'Gerente', '1,2,3,4,5,18,19,8,6,7,16,10,11', NULL, NULL, '0');
INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('14', 'dinho.braga', 'Erlandsson', 'Braga', 'd577cfc490cc93173c7733e71ecd9d876a6417705718ef8135dfed100f1f016995b4a5c83e8bcbe6e1e6ac1785eaf4965cad87d46d05cfb99312395d22fd7810', 'dinhobragacosta@gmail.com', 'active', '0', '2017-06-15 14:32:29', 'no-pic.png', 'Usuario', '1,2,3,4,18,6,7,16,10,11', '1498702618', '1498702410', '0');
INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('16', 'mayara.rodrigues', 'Mayara', 'Rodrigues', 'eb2c3a3d61dc16d8518a1a238ad88934f39541acf2813b8347a748e6c8fe63d6ad42a788bf0b2ee7210506c9d035e463a9c82322a23398d8233c431b5c584d6b', 'ma_prodrigues@hotmail.com', 'active', '0', '2017-06-19 21:38:13', 'no-pic.png', 'Usuario', '1,2,3,4,5,18,19,8,6,7,16,10,11', NULL, NULL, '0');
INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('17', 'victor.henrique', 'Victor', 'Henrique Miranda Silva', 'd02d5c33e4b685b7b1554397ac97a1853f1ca21529bbcd2e84fa4dd6df5115a60fb925fb10ee186fa9882bdf825af0ff99e8e6f215d4d155c70875a2d8f99082', 'vic.tinhomt2@gmail.com', 'active', '0', '2017-06-20 12:58:24', 'no-pic.png', 'Usuário', '1,2,3,4,6,7,16,10,11', '0', '1497974504', '0');



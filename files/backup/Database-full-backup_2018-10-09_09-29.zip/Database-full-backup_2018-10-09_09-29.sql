#
# TABLE STRUCTURE FOR: article_has_attachments
#

DROP TABLE IF EXISTS article_has_attachments;

CREATE TABLE `article_has_attachments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `article_id` bigint(20) DEFAULT '0',
  `filename` varchar(250) DEFAULT '0',
  `savename` varchar(250) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: clients
#

DROP TABLE IF EXISTS clients;

CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(140) DEFAULT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `email` varchar(180) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  `mobile` varchar(25) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `zipcode` varchar(30) NOT NULL,
  `userpic` varchar(150) NOT NULL DEFAULT 'no-pic.png',
  `city` varchar(45) DEFAULT NULL,
  `hashed_password` varchar(255) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `access` varchar(150) DEFAULT '0',
  `last_active` varchar(50) DEFAULT NULL,
  `last_login` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8;

INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('29', '26', 'Rafael ', 'Bitencourt Palma', 'financeiro@montpiscinas.com.br', '', '(11) 99307-5767', '', '', 'no-pic.png', 'São Pualo', '3d7846418186741b8e858d36b2f88e6594c062733b92f2ebebbec8205e03f6d1455a354ab0baf07e580b304573924cd8d1e67699344eb0b64aadcae19eab03bf', '0', '14,12,17', '0', '1497642276');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('30', '28', 'Valdiva ', 'Batista Pereira', 'diva@divalingerie.com.br', '', '(11) 95895-6419', 'Rua Itrapoá', '04950-140', 'no-pic.png', 'São Paulo', 'f764bc54fa62d5573bdc2e54a6ff8da357158efbd979440648bd51629a503fceb23f70fab08e4e4d16ab44dead400cfc2b1c4de9b446d01110dd97570f252d5d', '0', '14,12,17', '0', '1521045793');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('41', '39', 'kaique', 'kaique', 'kaique@websitego.com.br', '', '', 'teste', '04864030', 'no-pic.png', 'são paulo', '12472d09c1644a306973451ea0b0e28a6d2546fb5439a8303c940f72fbed4815e921fa3f64afb556709f5e4411396a7e0ce85cb88590d56e7c12bc487db92c10', '1', '14,12,13,17,', '0', '1499985010');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('44', '42', 'Website GO Serviços ', 'LTDA', 'thiago@websitego.com.br', '1158956419', '11992429212', 'Rua Itrapoá ', '04950140', 'no-pic.png', 'SP', '0cae0143de58f7467bf7d14b52ed6dcb79c46d18408187d8aa45df4f6b6be7bfecf563b05522ed69f7c986e10b54df0bc2520103628ad298b8bc488b8e308198', '1', '14,12,13,17', '0', '1505569040');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('45', '43', 'Vagner', 'Alferes nissimura', 'vagner_nissimura@yahoo.com.br', '', '973490582', '', '', 'no-pic.png', 'São paulo', '9fda4c8822d5d07f355efb8aca07b65af44b66bf4447c6628d5cdeaa56ab91affb0685aea73212a777aad0009916c01b8a440a3dc12e28f888376ba4cb3f4742', '1', '14,12,13,107,15,17', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('46', '44', 'Vitor Leandro', 'Blasetti', 'vitor@vbarquiteturainteriores.com.br', '', '11941353990', 'Rua Atuai, 775 casa 3', '03646000', 'no-pic.png', 'São Paulo', '90217a775041aa09d488163ebc826d68b7cb1dcf3ed4ff2bfabe976f58239df4aa09b36cc504416d1f14309f4d2ec0342b94bd2f509f3e3e46d053ed83f4f69f', '0', '14,12,17', '1506391273', '1506391272');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('47', '45', 'Vagner', 'Alferes nissimura', 'vagner_nissimura@yahoo.com.br', '', '11 97349-0582', 'Rua Um', '04880600', 'no-pic.png', 'São Paulo', '5767c0b8dacf0d1e37353756ad3e0a10d082343cb30f173a3254efcd2a17ef7168638ffc1dc3c4cec6c48f8cc03a585a48377d326df571bf8f2278a6b1987a59', '1', '14,12,13,107,15,17', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('49', '49', 'Josiane ', 'Ferreira da Silva', 'jjosi83@gmail.com', '55946313', '962883157', 'rua Alberto Leal 540 ', '04343000', 'no-pic.png', 'São Paulo ', '9d0d47cba66f95fcaa9e78971a565d4dfa73995cae9c123b5211fb32ef64eccde7f2bb8dac1e6be3575b40fee26ac5a35736fa219eeb355570dc4e39466cf804', '0', '14,12,17', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('50', '50', 'Jacquet Brasil S/A', '15.488.031/0001-00', 'talita.alcantara@jacquet.com.br', '(41) 3090-7800', '', '', '', 'no-pic.png', 'thiago.pimentel', '2a8614bbf8d8e877f98c3910d97ef926d2956833017ff64e94dfc0ebcbf57dea455103159e64d1c43b274ffdec479feb94cc71754dc8cf407c06665e5d1642ac', '0', '14,12,13,17', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('51', '51', 'Renê', 'Muniz', 'renemunizsilva@gmail.com', '', '11 9 9916-6570', 'Avenida Bezerra de Menezes, 251', '09851-130', 'no-pic.png', 'São Bernardo do Campo', 'd5bf8577da4eea9a181a119e184939fa412f9d5e6ecf003e657752ca18c1d7fd07d1beb16e1e3cf9e44273a3189ad34b8954ff4ff52429d9192a41d30b9b78c5', '0', '14,12,17', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('52', '53', 'websitego', 'websitego', 'contato@websitego.com.br', '1126268159', '', 'Rua Itrapoá', '04950140', 'no-pic.png', 'são paulo', 'ce3767ae03a070bd3f15e92a86216c44db8feda66ce37694d5ee60d5dbe28cd5bb2e10e2def88b4e9a07718bea79006a98ecc946b8f3d2cb5de5ed608784538f', '1', '14,12,13,17', '0', '1515163707');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('54', '55', 'Miguel', 'Alves', 'miguel@miguel.com.br', '11975076059', '11998547100', 'Teste', '04880600', 'no-pic.png', 'São Paulo', 'fb0453906cf89c437221aba9a4a73bbdf67861d86fbd7d87da31c87b0f8e549fa4c1f037d4590def0b4951ae5dd870823628087552e2a8fd6e605b371c66e29f', '1', '14,12,13,17,', '0', '1515852435');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('55', '56', 'Cristiana ', 'Oliveira Lino', 'mooca.consorcio@vwamazon.com.br', '11 3451 4684', '11 98527 0729', 'Av. Alcântara Machado, 638', '03102001', 'no-pic.png', 'São paulo', '73aeda61c9c812a3dde80f838480932bb94f9c40dd19f4144d39c88aa11c4dd55159f5e2325b2c38ad46cf9061b21caf197ca829ab9e8bec38aa2a2a963a62a0', '0', '14,12,17', '1525976492', '1525976439');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('56', '57', 'Gislaine ', 'Alves de Souza', 'sbm@sbmmetalicos.com.br', '47233652', '947741501', 'Av. JAPÃO, 2742', '08730330', 'no-pic.png', 'Mogi das Cruzes', '2724a6a27850f04378fdd9dbcce3dc2b3c3fa34c5c27d6f43e37a77e61e0d1688f035dd0f9b85d95cad67d570ca22ea8d8874e6e5b030594cf377c61b9cc0594', '0', '14,12,17', '0', '1517585464');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('57', '58', 'VAGNER', 'EDILON SANTOS CUNHA', 'VAGNEREDILON@GMAIL.COM', '(61) 99261-5153', '(61) 99261-5153', '000 QR 218 CONJUNTO G', '72548-507', 'no-pic.png', 'BRASILIA/DF', '0b30cb190f154c43f605e7aa470b0de788e9a524b21e0a0bebaf37b4eb55ccce980daf0bf26286a1cd69010b28c00a19c423a83439d24c92bf14f1de9d4d7c96', '1', '14,12,17', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('58', '59', 'Erica ', 'Duarte Ribeiro Rocha ', 'lavanderiawow@outlook.com', '', '1194025-8230', 'Rua Pedro Taques, 235', '06716312', 'no-pic.png', 'São Paulo ', 'bca2fb1156b6856a18b8a65a63ec1ad8fd9576ec6f2dcd20343278b5e09e12838942209e73b6062d5c295b8efbdf306f81c8b8a19ce9168e3383a0fa4ba62994', '0', '14,12,17', '1529597997', '1529597978');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('59', '60', 'Valdir ', 'Fernandes', 'valdir.fernandes@ymail.com', '019 30345592', '019 993242830', 'Rua natalino barros sampaio', '5519993242830', 'no-pic.png', 'Limeira ', '36cc9dd0958b0aeeb0b46c9aec1ef55829044e279dbd04bff54e776819c09f7d43cbf44eb59b0af1aaff9489736c2c2229b385267d2110f016c21aaf8592d59f', '1', '14,12,13,17,', '1522087439', '1522087216');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('60', '61', 'Tialitom ', 'Jheiques', 'thialiton_costa@hotmail.com', '(69) 984469611', '69984469611', 'Rua castanheiras 2958', '76993000', 'no-pic.png', 'Colorado do oeste ', '5ca442287fcd500ab2c39fd3936d8d0b0bdcbef642cf5e7487971685fc8678a4cc3bbdd275a3f56f400b0b1899eeb47781c677b3fbb6cfe08f083b918a45b0de', '1', '14,12,17', '1523494661', '1523467925');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('61', '62', 'Hailton dos Santos ', 'SANTOS', 'pastorhailton1@gmail.com', '(21)38374366', '(21)982891853', 'Estrada João Paulo n.1260- 2 andar', '21512-002', 'no-pic.png', 'Rio de Janeir', 'e237727272da684d18719e56f2f7767b9ee5f1980220da5aaf5accf5cc98c6ef83f6ea836f05248dbeb263fd74b7581bee26fd16407144393d749e569b1a53fe', '0', '14,12,17', '1524170233', '1524169937');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('62', '52', 'THIAGO', ' PEREIRA PIMENTEL', 'thiago@websitego.com.br', '', '', '', '', 'no-pic.png', '', '30248f973218e68d91bd05170c55008e9f567ce8cc34a922c8c3e5174bd7f3ca64b7228292fa1621a22861c7067eba28f15ce304d842eb4a9d794cce81b25def', '0', '14,13', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('63', '63', 'Peterson', 'Muliterno', 'globalelevadores@oi.com.br', '8132444851', '81988035077', 'Travessa arsenal de guerra 135', '50020630', 'no-pic.png', 'Recife', 'da5fd33ca2787c1fc5a5f3392bd5e4982f2ba1872bd03f576bf81d43566646371e57ac3998f4f9165c110121be84aecdcdf1ea20e0401e8e5a9c3c561a1df935', '0', '14,12,17', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('64', '64', 'Renato ', 'De Sousa Ferreira ', 'atendimento@doutorrenato.com.br', '(34 )3316-6283', '(34) 99284-0572', 'Rua dona maria da gloria leao borges 190 amor 704', '38020-330', 'no-pic.png', 'Uberaba ', '10a5043c0b7d7b195384d32932aad1df8a37bebf64856d5f38a9058eca8a7b2aa59a94daac3d439cec0582bd1fe2f3d1ad2dc5c8f23a60ba7a682ab7e0cc133f', '0', '14,12,17', '1528850833', '1528850809');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('65', '65', 'Renato', 'Bezulle', 'renato@magicimpress.com.br', '1126389188', '', 'Rua Camacam, 413', '05095000', 'no-pic.png', 'São Paulo', '86f128e387ee59178f58e3dc08e2bc6bf44ee9407cff8f5469829855dd15f9264e87a5c1e0fdb28ffc39523eba80f4a73cfffbb0c175b6950c12390cf76dd5fa', '0', '14,12,17', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('66', '66', 'Leandro ', 'Bispo de melo', 'dulelupinturas@gmail.com', '', '1198628-1584', 'Rua João Sussumo Hirata 100', '06770-250', 'no-pic.png', 'Taboão da Serra', '88cb2e49d4958280c0a08c272eb133e84dca7ad85e834e52e43dbe0b18d1f76196a737af6fe99c65fd0b81b553516c6e0c09d4b938865326239ddf1bb7be9d14', '0', '14,12,17', '1532014628', '1532014595');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('67', '67', 'Renato', 'Rocha', 'reroc1212@gmail.com', '27998682838', '', 'Rua Itacibá 135, Ed. Villagio Itaparica, 135', '29102280', 'no-pic.png', 'Vila Velha', 'b69f1465f9e781eedfcd422b309d8414c7fdb10b77a2aaece1ac3fa329fa0b91ed0f10789cd3263aa57862807480f08028b53f4db63b9b8fa9f02e8305ef50e8', '0', '14,12,17', '1532530152', '1532530151');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('68', '68', 'Carlos ', 'Lima', 'ti@costaoesteserv.com.br', '45 3055 3644', '9 9916 2429', 'Rua nossa senhora do rocio 1901', '85900180', 'no-pic.png', 'toledo', 'baeb9f51652ef3bba84e0c49b8927314bb39efd7323a0b46b5b9550b63df5a526a2005f561c45714d8d3284de8571676455fb5f55e611a7dd473df42dbc464b4', '0', '14,12,17', '1534879085', '1534879067');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('69', '69', 'Andria', 'Galeazi Jacob', 'adm@artbiz.biz', '11 5096-2505', '11 98193-1028', 'Rua Gabriele D´Annunzio, 1287', '04619-005', 'no-pic.png', 'Sâo Paulo', 'b106f3ee15601274f648fd13538bcb6d83fc1c7d4e284c0de6370a12a7841f6e0f892358507cb44c77b5b4b7ee143222525571706387229f52a66e19428b153c', '0', '14,12,17', '1532972554', '1532972541');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('70', '70', 'pedro', 'henrique', 'curtseguir@gmail.com', '', '081 997653734', 'rua popular', '52091090', 'no-pic.png', 'recife', '68e12170891111f017f7a912e3193acc5fcae9f8bb52ada413ac74474f5318e26c6ed68015a0c2c7d01f9b7de45bd27e037d268e6e865092037cef23a80d5679', '1', '14,12,17', '0', '1533065955');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('71', '71', 'Alexsandro', 'Biagi', 'biagi_alex@yahoo.com.br', '', '22996031090', 'Rua Madre Tereza de Calcutá, , Casa 02', '28895616', 'no-pic.png', 'Rio das Ostras', '6493f1b8851694aa107516c2c870a69fc9b488e33b1548707ea77b463feb5c025f2e1b6f2f07e68e4bb638106094ab6326d7a94ae9da5edf8b6c786573b5c33e', '0', '14,12,17', '0', '1533586147');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('72', '72', 'Nilva', 'Gagliardi', 'nilva@buffetdebora.com.br', '(11)3903 5998', '(11)941111797', 'Rua Carlos Malheiros Dias 269', '05170-040', 'no-pic.png', 'São Paulo', 'a8c1f3fa464fb3ddb3eb9f6d9c04bf99111c90b8eec9f96ce4c229c94185322f5f8a44f6190b272aca7ed07b1f8f273038f6258d284fb08f845b6d9486b1e0bb', '0', '14,12,17', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('73', '73', 'Anderson Caetano ', 'Sitta ', 'sittainox@gmail.com', '1139716728', '11987479721', 'Av. Sapucaia do Sul ', '02952160', 'no-pic.png', 'São Paulo ', 'b6ae323bbd94f35a1535ec4a837dff50ba8988b97e2d4fb11f5a7b8e111a28bed6ff6e8437bd8e7e81a67b08312569e0f210e3657b249b0a637b0699fd452483', '0', '14,12,13,17,', '1533825393', '1533825354');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('74', '74', 'Claudio', 'Fragoso', 'claudio.fragoso@inboxbrasil.com.br', '27 3369-9390', '27 99226-9023', 'Avenida Primeira,500', '29111160', 'no-pic.png', 'Vila Velha', '653b5e18137e73a6783fb383c4b213faf03be7feb41c1c071c42e0c13900c67cfac4ff10bc891a64e6bafae2079ea0a054f510c04d0ff979aaa985497ebf3d13', '0', '14,12,13,17,', '1534165205', '1534165204');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('75', '75', 'Eduardo ', 'de Santana ', 'eduartcomunicacaovisual@gmail.com', '', '953480200', 'Rua Domingo De Goes 89', '05767340', 'no-pic.png', 'São Paulo', '77055343fdd0deedd9d8a402e9e33035820100617fba923998fa1c4716813f4726fadfd487f94c79bd4593e5dffa61c0f3b117c915c12e8053fa89cbe07127b2', '0', '14,12,13,17,', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('76', '76', 'Sônia ', 'Maria Silva Sousa', 'amandabechpw@hotmail.com', '6232951383', '62982632520', 'Rua sv39 Qd54 Lt10', '74470545', 'no-pic.png', 'Goiânia', 'a9b27eff2b4b029f1a707f040c59090ba3ca9a1d6872c7677e6205b1af9005954eaf06d0eb5ca4ad47f47bed8632c3b1c2c97929fc538a76c830cd6e83a707f7', '0', '14,12,13,17,', '1534779953', '1534779940');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('77', '77', 'FLORISVALDO ', 'DA SILVA LIMA', 'valdohardware@hotmail.com', '11951450973', '11951450973', 'RUA FILOMENO JOSE DA COSTA 3', '08042150', 'no-pic.png', 'SAO PAULO', 'ac0336262dbc114bc9b1737db08243277fd2dbd98d0d83eebf9048f6936615bc52e3019984bc17edd243059dc60d2ee1c5c2b930bffd999e8ed7889da5ef3133', '0', '14,12,13,17,', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('78', '78', 'Ricardo', 'Dainez Forcan', 'ricardoforcan@gmail.com', '+5511979757579', '979757579', 'Rua Padre Anibal Difrancia, 382', '5511979757579', 'no-pic.png', 'São Paulo', '3bb21d4be014dc8256983836d93989508cb2ff6c24eb6a5027c85820aac57a25b8816a4af5eeab9d948551288246147cf1f830b49151fc33b59817a0aef48b37', '0', '14,12,13,17,', '1534976578', '1534970901');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('79', '79', 'MAURICIO', 'MOREIRA DE FARIAS', 'mauriciorefri@yahoo.com.br', '(21) 3566 - 6096', '(21) 96431 - 3727', 'ESTRADA VELHA DO PILAR 2984 QD 16 LT 11 - A - CASA 15 - CHÁCARAS RIO PETRÓPOLIS', '25230-610', 'no-pic.png', 'CAXIAS', 'fb425203e9e50c450b9888741fa19979f249f64af0053db0a2545393d0a2516cdcc42750e2d68bc772ab2ca0c087bd6d2a315d83f0c6796c18a403f5c0e3736e', '0', '14,12,13,17,', NULL, NULL);
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('80', '80', 'Ezequias Soares da ', 'Silva', 'ezequiassoares@hotmail.com', '11-34311660', '11985667481', 'Rua  galiano  21', '04337130', 'no-pic.png', 'São Paulo ', 'a225b85bd9a2b985aae74efa2f01cf5492f3935d44b88576e92c7f4a025f42cae2078204625f97625c0bccc469241358b8d2c9616fbb336d699e97782b41acd9', '0', '14,12,13,17,', '0', '1536076233');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('81', '81', 'Mauro ', 'Roberto Emílio Filho', 'patricia@besmodel.com.br', '(11) 2031-2317', '(11) 95431-2260', 'Rua: Capitão Francisco Isaías de Carvalho, 166', '08010-030', 'no-pic.png', 'São Paulo', '289c042f67ddaecaafaccfa5c5ee97d32ab1f3f2ac22e5979893df7d93e92924a5794b63e7fbdf9c821236f70b2b9e96b5bd019ff5ae8646c324373f2eedb542', '0', '14,12,13,17,', '1536159738', '1536159692');
INSERT INTO clients (`id`, `company_id`, `firstname`, `lastname`, `email`, `phone`, `mobile`, `address`, `zipcode`, `userpic`, `city`, `hashed_password`, `inactive`, `access`, `last_active`, `last_login`) VALUES ('82', '82', 'Cleber', 'Pernetti ', 'Cleber@hqgsollutions.com.br', '11981229276', '11981229276', 'Rua eng. Mesquita Sampaio, 131', '04711000', 'no-pic.png', 'São Paulo', 'c2eee5f5550ff78bfbcb1a30bab43e0f1b3f64c2f5c5d3cb0dc184e770a0de26d4b2a3eca9a89c21b40b4f4ecf310183f3fe5b40ac543ead39615b78f319c60e', '0', '14,12,13,17,', '1538145542', '1538145527');


#
# TABLE STRUCTURE FOR: companies
#

DROP TABLE IF EXISTS companies;

CREATE TABLE `companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` int(11) NOT NULL,
  `name` varchar(140) DEFAULT NULL,
  `client_id` varchar(140) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  `mobile` varchar(25) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `zipcode` varchar(30) NOT NULL,
  `city` varchar(45) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `website` varchar(250) DEFAULT NULL,
  `country` varchar(250) DEFAULT NULL,
  `vat` varchar(250) DEFAULT NULL,
  `note` longtext,
  `province` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('26', '41002', 'Rafael Bitencourt Palma / CPF 37356223805', '29', '(11) 99307-5767', '(11) 99307-5767', '', '', 'São Paulo', '0', 'montpiscinas.com.br', 'Brasil', '', 'Hospedagem de sites Basic: &lt;br&gt;Registro de domínio: montpiscinas.com.br&lt;br&gt;E-mail secundário: leandro_pate@hotmail.com', 'SP');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('28', '41004', 'Valdiva Batista Pereira / CPF 164.156.818.69', '30', '', '(11) 95895-6419', '', '04950-140', 'São Paulo', '0', 'divalingerie.com.br', 'Brasil', '', 'Registro de Domínio: divalingerie.com.br', 'SP');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('32', '41008', 'teste', '34', '', '', 'teste', '04846030', 'teste', '1', '', 'teste', '', NULL, '');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('33', '41009', 'teste', '35', '', '', '', '', '', '1', '', '', '', NULL, '');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('34', '41010', 'teste', '36', '', '', '', '', '', '1', '', '', '', NULL, '');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('37', '41013', 'Teste Kaique', '39', '', '', 'teste', '04864030', 'São Paulo', '1', '', 'Brasil', '', NULL, 'SP');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('38', '41014', 'Augusto', '40', '', '11948585258', 'Rua Selma Kurtz 87', '04434010', 'São Paulo', '1', 'uol.com.br', 'Brasil', '', NULL, 'São Paulo');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('39', '41015', 'kaique', '41', '', '', 'teste', '04864030', 'são paulo', '1', '', 'brasil', '', NULL, 'SP');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('40', '41016', 'Enloogs', '42', '1146446976', '11966263582', 'Rugiero Fedeli', '04963190', 'São Paulo', '1', 'enloogs.com.br', 'Brasil', '', NULL, 'São Paulo');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('41', '41017', 'Teste Não apagar', '43', '', '', '', '', '', '1', '', '', '', NULL, '');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('42', '41018', 'Website GO Serviços LTDA', '44', '1158956419', '11992429212', 'Rua Itrapoá ', '04950140', 'São Paulo', '1', 'websitego.com.br', 'Brasil', '', NULL, 'SP');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('43', '41019', 'Vagner Alferes nissimura (japa)', '45', '', '', '', '', '', '1', '', '', '', NULL, '');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('44', '41020', 'Vitor Leandro Blasetti / CPF 365.735.458-18', '46', '', '11941353990', 'Rua Atuai, 775 casa 3', '03646000', 'São Paulo', '0', 'vbarquiteturainteriores.com.br', 'Brasik', '', 'E-mail secundário: vitor@vbarquiteturainteriores.com.br', '');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('45', '41021', 'Vagner Alferes nissimura (japa)', '47', '', '', 'Rua Um', '04880600', 'São Paulo', '1', '', 'Brasil', '', NULL, 'SP');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('46', '41022', 'Thiago', NULL, '1158956419', '11992429212', '', '04950140', 'são paulo', '1', 'websitego.com.br', 'br', '', NULL, '');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('47', '41023', 'teste', NULL, '1158956419', '9992429212', '', '04950140', 'so', '1', 'teste.com.br', 'sp', '', NULL, '');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('48', '41024', 'jeni', '48', '1158956419', '', 'rua itrapoa', '04950440', 'sp', '1', 'jenisafada.com.br', 'br', '', NULL, 'sp');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('49', '41025', 'Kingyo Temakeria / CNPJ 202884100001/97', '49', '55946313', '962883157', 'rua Alberto Leal 540 ', '04343000', 'São Paulo ', '0', 'kingyotemakeria.com.br', 'Brasil ', '', NULL, 'SP');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('50', '41026', 'Jacquet Brasil S/A / CNPJ 15.488.031/0001-00', '50', '(41) 3090-7800', '', '', '80.250-104', 'Curitiba', '0', 'jacquet.com.br', 'BR', '15.488.031/0001-00', '&lt;p style=&quot;margin: 0cm 0cm 0.0001pt; font-size: 12pt; font-family: &quot; times=&quot;&quot; new=&quot;&quot; roman&quot;,=&quot;&quot; serif;&quot;=&quot;&quot;&gt;&lt;br&gt;&lt;/p&gt;', 'PR');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('51', '41027', 'Renê Muniz  / CPF 335.103.058-41', '51', '', '11 9 9916-6570', 'Avenida Bezerra de Menezes, 251', '09851-130', 'São Bernardo do Campo', '0', 'renemuniz.net', 'Brasil', '', NULL, 'São Paulo');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('52', '41028', 'WebsiteGO Servicos LTDA / CNPJ 27.760.132/0001-78', '62', '11992429212', '', 'Rua Itrapoá', '04950140', 'São Paulo', '0', 'websitego.com.br', 'Brasil', '', '&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;font-size: 13.3333px; background-color: yellow;&quot;&gt;Kaique Paes Alves&lt;/span&gt;&lt;br&gt;&lt;/p&gt;&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;Ag: &lt;/span&gt;2921&lt;/p&gt;&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;CC: &lt;/span&gt;35972-1&lt;/p&gt;&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;Itaú&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;background-color: yellow;&quot;&gt;Thiago Pereira Pimentel dos Santos&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;Ag: &lt;/span&gt;1667&lt;/p&gt;&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;CC: &lt;/span&gt;43286-6&lt;/p&gt;&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;Itaú&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;background-color: rgb(255, 255, 0);&quot;&gt;Leandro Júlio Santana&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;AG:&lt;/span&gt; 8161&lt;/p&gt;&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;CC:&lt;/span&gt; 06214-9&lt;/p&gt;&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;font-size: 13.3333px; font-weight: 700;&quot;&gt;Itaú&lt;/span&gt;&lt;br&gt;&lt;/p&gt;&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;background-color: rgb(255, 255, 0);&quot;&gt;Victor Henrique Miranda Silva&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;AG:&lt;/span&gt;0160&lt;/span&gt;&lt;br&gt;&lt;/p&gt;&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;CC:&lt;/span&gt; 17855-4&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;font-size: 13.3333px; font-weight: 700;&quot;&gt;Itaú&lt;/span&gt;&lt;span style=&quot;font-size: 13.3333px;&quot;&gt;&lt;br&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;background-color: rgb(255, 255, 0);&quot;&gt;Erlandisson Braga&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;font-size: 13.3333px;&quot;&gt;PENDENTE&lt;/span&gt;&lt;span style=&quot;background-color: rgb(255, 255, 0);&quot;&gt;&lt;br&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;font-size: 13.3333px;&quot;&gt;&lt;br&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;font-size: 13.3333px;&quot;&gt;&lt;br&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;font-size: 13.3333px; font-weight: bold;&quot;&gt;Dados para Boleto Bancário:&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;&quot;&gt;&lt;span style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;I Pagamento pode ser realizado em qualquer banco&lt;/span&gt;&lt;br&gt;&lt;/p&gt;&lt;p style=&quot;&quot;&gt;&lt;span style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;II Srº Caixa,não aceitar apos o vencimento&lt;/span&gt;&lt;br&gt;&lt;/p&gt;&lt;p style=&quot;&quot;&gt;&lt;span style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;III Suporte financeiro: financeiro@websitego.com.br&lt;/span&gt;&lt;br&gt;&lt;/p&gt;&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;font-size: 13.3333px;&quot;&gt;&lt;br&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;font-size: 13.3333px;&quot;&gt;&lt;br&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;font-family: Verdana, Geneva, sans-serif; font-size: 13.3333px;&quot;&gt;&lt;span style=&quot;font-size: 13.3333px;&quot;&gt;&lt;br&gt;&lt;/span&gt;&lt;/p&gt;', 'SP');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('53', '41029', 'websitego', '0', '1126268159', '', 'Rua Itrapoá', '04950140', 'são paulo', '1', 'websitego.com.br', 'brasil', '', NULL, 'sp');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('54', '41030', 'luiz', '53', '', '11992429212', 'Rua Itrapoá', '04950140', 'sao paulo', '1', 'www.teste.com.br', 'br', '41553827848', NULL, 'sp');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('55', '41031', 'Miguel', '54', '11975076059', '11998547100', 'Teste', '04880600', 'São Paulo', '1', '', 'Brasil', '40716300869', NULL, 'SP');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('56', '41032', 'Consorcio Volkswagen', '55', '11 3451 4684', '11 98527 0729', 'Av. Alcântara Machado, 638', '03102001', 'São paulo', '0', 'consorciovwdefabrica.com.br', 'Brasil', '27112994810', '&lt;div&gt;Acesso GMAIL &lt;/div&gt;&lt;div&gt;consorciovwonline@gmail.com&lt;/div&gt;&lt;div&gt;senha: Welcome100%&lt;/div&gt;', 'São Paulo');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('57', '41033', 'SBM Metálicos', '56', '47233652', '947741501', 'Av. JAPÃO, 2742', '08730330', 'Mogi das Cruzes', '0', 'sbmmetalicos.com.br', 'Brasil', '48582237871', NULL, 'São Paulo');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('58', '41034', 'VSEGDF', '57', '(61) 99261-5153', '(61) 99261-5153', '000 QR 218 CONJUNTO G', '72548-507', 'BRASILIA/DF', '1', 'vsegdf.com.br', 'Brasil', '16.728.625/0001-04', NULL, 'Distrito Federal');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('59', '41035', 'Lavanderia Wow ', '58', '', '1194025-8230', 'Rua Pedro Taques, 235', '06716312', 'São Paulo ', '0', 'lavanderiawow.com.br', 'Brasil', '08087752783', NULL, 'São Paulo');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('60', '41036', 'VF Móveis Planejados', '59', '019 30345592', '019 993242830', 'Rua natalino barros sampaio', '5519993242830', 'Limeira ', '1', '', 'Brasil', '23108778000114', NULL, 'São Paulo ');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('61', '41037', 'Anjo publicidade', '60', '(69) 984469611', '69984469611', 'Rua castanheiras 2958', '76993000', 'Colorado do oeste ', '1', 'Anjopublicidade.com.br', 'Brasil', '03109467275', NULL, 'Ro');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('62', '41038', 'Cmeb convenção de Ministros Evangélicos.do Brasilbrasil', '61', '(21)38374366', '(21)982891853', 'Estrada João Paulo n.1260- 2 andar', '21512-002', 'Rio de Janeir', '0', 'www.cmebrio.com.br', 'Brasil', '117392750001-68', NULL, 'RJ');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('63', '41039', 'Global elevadores ltda', '63', '8132444851', '81988035077', 'Travessa arsenal de guerra 135', '50020630', 'Recife', '0', 'globalelevadores.com', 'Brasil', '06310147000164', NULL, 'PE');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('64', '41040', 'Doutor Renato ', '64', '(34 )3316-6283', '(34) 99284-0572', 'Rua dona maria da gloria leao borges 190 amor 704', '38020-330', 'Uberaba ', '0', 'www.doutorrenato.com.br', 'Brasil ', '62821091672', '&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Acesso no painel da Locaweb:&lt;/div&gt;&lt;div&gt;Login: doutorrenato&lt;/div&gt;&lt;div&gt;Senha: hoc1341&lt;/div&gt;&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;&lt;br&gt;&lt;/div&gt;', 'Minas Gerais ');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('65', '41041', 'RGT INDÚSTRIA GRÁFICA E EMBALAGENS - EIRELI - EPP', '65', '1126389188', '', 'Rua Camacam, 413', '05095000', 'São Paulo', '0', 'www.magicindustria.com.br', 'Brasil', '11063262000111', NULL, 'São Paulo');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('66', '41042', 'Dulelo Pinturas', '66', '', '1198628-1584', 'Rua João Sussumo Hirata 100', '06770-250', 'Taboão da Serra', '0', 'dulelupinturas.com.br', 'Brasil', '27342589861', NULL, 'São paulo');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('67', '41043', 'atto', '67', '27998682838', '', 'Rua Itacibá 135, Ed. Villagio Itaparica, 135', '29102280', 'Vila Velha', '0', 'attoserv.com.br', 'Brasil', '', NULL, 'Espírito Santo');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('68', '41044', 'Costa Oeste Serviços de Limpeza', '68', '45 3055 3644', '9 9916 2429', 'Rua nossa senhora do rocio 1901', '85900180', 'toledo', '0', 'http://www.costaoesteserv.com.br/', 'brasil', '07.192.414/0001-09', NULL, 'parana');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('69', '41045', 'Artbiz - Artes Visuais - Comunicação Visual', '69', '11 5096-2505', '11 98193-1028', 'Rua Gabriele D´Annunzio, 1287', '04619-005', 'Sâo Paulo', '0', 'artbiz.biz', 'Brasil', '07.187.154/0001-83', NULL, 'SÂO PAULO');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('70', '41046', 'curtseguir.com', '70', '', '081 997653734', 'rua popular', '52091090', 'recife', '1', 'curtseguir.com.br', 'brasil', '35582789847', NULL, 'pernabuco');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('71', '41047', 'Abiagi Refrigeração', '71', '', '22996031090', 'Rua Madre Tereza de Calcutá, , Casa 02', '28895616', 'Rio das Ostras', '0', '', 'Brasil', '25263677000143', NULL, 'RJ');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('72', '41048', 'Massas Congeladas ', '72', '(11)3903 5998', '(11)941111797', 'Rua Carlos Malheiros Dias 269', '05170-040', 'São Paulo', '0', 'www.massascongeladas.com.br', 'Brasil', '001698168-50', NULL, 'São Paulo');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('73', '41049', 'Sittainox', '73', '1139716728', '11987479721', 'Av. Sapucaia do Sul ', '02952160', 'São Paulo ', '0', 'sittainox.com.br', 'Brasil ', '32224935889', NULL, 'São Paulo ');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('74', '41050', 'INBOXBRASIL ORGANIZAÇÃO E GUARDA DE DOCUMENTOS LTDA', '74', '27 3369-9390', '27 99226-9023', 'Avenida Primeira,500', '29111160', 'Vila Velha', '0', 'www.inboxbrasil.com.br', 'Brasil', '08.596.565/0001-95', NULL, 'Espírito Santo');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('75', '41051', 'Eduart Comunicação Visual', '75', '', '953480200', 'Rua Domingo De Goes 89', '05767340', 'São Paulo', '0', 'eduartcomunicacaovisual.com.br', 'Brasil', '34036812890', '&lt;span style=&quot;color: rgb(204, 204, 204); font-family: MyHelveticaNeue, Arial, TeXGyreHeros, sans-serif; background-color: rgb(106, 106, 106);&quot;&gt;EDSAN869&lt;/span&gt;&lt;div&gt;&lt;span style=&quot;color: rgb(204, 204, 204); font-family: MyHelveticaNeue, Arial, TeXGyreHeros, sans-serif; background-color: rgb(106, 106, 106);&quot;&gt;eduartcomunicacao@10&lt;/span&gt;&lt;/div&gt;&lt;div&gt;&lt;span style=&quot;background-color: rgb(106, 106, 106);&quot;&gt;&lt;span style=&quot;color: rgb(204, 204, 204); font-family: MyHelveticaNeue, Arial, TeXGyreHeros, sans-serif;&quot;&gt;https://registro.br/2/confirmacao-usuario/22708F25BEP18735191&lt;/span&gt;&lt;br&gt;&lt;/span&gt;&lt;/div&gt;', 'São Paulo');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('76', '41052', 'MK Modelagem', '76', '6232951383', '62982632520', 'Rua sv39 Qd54 Lt10', '74470545', 'Goiânia', '0', 'não possui', 'Brasil', '47135093291', NULL, 'GO');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('77', '41053', 'VS CONTROLES DE ACESSOS E CFTV', '77', '11951450973', '11951450973', 'RUA FILOMENO JOSE DA COSTA 3', '08042150', 'SAO PAULO', '0', 'www.vscontroledeacesso.com.br', 'Brasil', '02297082770', NULL, 'SP');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('78', '41054', 'Dainez Forcan', '78', '+5511979757579', '979757579', 'Rua Padre Anibal Difrancia, 382', '05110-902', 'São Paulo', '0', 'Www.dainezforcan.com.br', 'Brasil', '35157495862', NULL, 'Sp');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('79', '41055', 'MM FARIAS -ME', '79', '(21) 3566 - 6096', '(21) 96431 - 3727', 'ESTRADA VELHA DO PILAR 2984 QD 16 LT 11 - A - CASA 15 - CHÁCARAS RIO PETRÓPOLIS', '25230-610', 'CAXIAS', '0', '', 'BRASIL', '20.230.433/0001-40', NULL, 'RJ');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('80', '41056', 'Limpa mais  ', '80', '11-34311660', '11985667481', 'Rua  galiano  21', '04337130', 'São Paulo ', '0', '', 'Brasil', '76065260444', NULL, 'São Paulo ');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('81', '41057', 'Brother & Sister Model LTDA - ME', '81', '(11) 2031-2317', '(11) 95431-2260', 'Rua: Capitão Francisco Isaías de Carvalho, 166', '08010-030', 'São Paulo', '0', 'www.besmodel.com.br', 'Brasil', '29.183.719/0001-97', NULL, 'São Paulo');
INSERT INTO companies (`id`, `reference`, `name`, `client_id`, `phone`, `mobile`, `address`, `zipcode`, `city`, `inactive`, `website`, `country`, `vat`, `note`, `province`) VALUES ('82', '41058', 'HQG Sollutions', '82', '11981229276', '11981229276', 'Rua eng. Mesquita Sampaio, 131', '04711000', 'São Paulo', '0', 'Www.hqgsollutions.com.br', 'Brasil', '26960800000148', NULL, 'SP');


#
# TABLE STRUCTURE FOR: core
#

DROP TABLE IF EXISTS core;

CREATE TABLE `core` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` char(10) NOT NULL DEFAULT '0',
  `domain` varchar(65) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `tax` varchar(5) DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `autobackup` int(11) DEFAULT NULL,
  `cronjob` int(11) DEFAULT NULL,
  `last_cronjob` int(11) DEFAULT NULL,
  `last_autobackup` int(11) DEFAULT NULL,
  `invoice_terms` mediumtext,
  `company_reference` int(6) DEFAULT NULL,
  `project_reference` int(6) DEFAULT NULL,
  `invoice_reference` int(6) DEFAULT NULL,
  `subscription_reference` int(6) DEFAULT NULL,
  `ticket_reference` int(10) DEFAULT NULL,
  `date_format` varchar(20) DEFAULT NULL,
  `date_time_format` varchar(20) DEFAULT NULL,
  `invoice_mail_subject` varchar(150) DEFAULT NULL,
  `pw_reset_mail_subject` varchar(150) DEFAULT NULL,
  `pw_reset_link_mail_subject` varchar(150) DEFAULT NULL,
  `credentials_mail_subject` varchar(150) DEFAULT NULL,
  `notification_mail_subject` varchar(150) DEFAULT NULL,
  `language` varchar(150) DEFAULT NULL,
  `invoice_address` varchar(200) DEFAULT NULL,
  `invoice_city` varchar(200) DEFAULT NULL,
  `invoice_contact` varchar(200) DEFAULT NULL,
  `invoice_tel` varchar(50) DEFAULT NULL,
  `subscription_mail_subject` varchar(250) DEFAULT NULL,
  `logo` varchar(150) DEFAULT NULL,
  `template` varchar(200) DEFAULT 'blueline',
  `paypal` varchar(5) DEFAULT '1',
  `paypal_currency` varchar(200) DEFAULT 'EUR',
  `paypal_account` varchar(200) DEFAULT '',
  `invoice_logo` varchar(150) DEFAULT 'assets/blueline/img/invoice_logo.png',
  `pc` varchar(150) DEFAULT NULL,
  `vat` varchar(150) DEFAULT NULL,
  `ticket_email` varchar(250) DEFAULT NULL,
  `ticket_default_owner` int(10) DEFAULT '1',
  `ticket_default_queue` int(10) DEFAULT '1',
  `ticket_default_type` int(10) DEFAULT '1',
  `ticket_default_status` varchar(200) DEFAULT 'new',
  `ticket_config_host` varchar(250) DEFAULT NULL,
  `ticket_config_login` varchar(250) DEFAULT NULL,
  `ticket_config_pass` varchar(250) DEFAULT NULL,
  `ticket_config_port` varchar(250) DEFAULT NULL,
  `ticket_config_ssl` varchar(250) DEFAULT NULL,
  `ticket_config_email` varchar(250) DEFAULT NULL,
  `ticket_config_flags` varchar(250) DEFAULT '/notls',
  `ticket_config_search` varchar(250) DEFAULT 'UNSEEN',
  `ticket_config_timestamp` int(11) DEFAULT '0',
  `ticket_config_mailbox` varchar(250) DEFAULT NULL,
  `ticket_config_delete` int(11) DEFAULT '0',
  `ticket_config_active` int(11) DEFAULT '0',
  `ticket_config_imap` int(11) DEFAULT '1',
  `stripe` int(11) DEFAULT '0',
  `stripe_key` varchar(250) DEFAULT NULL,
  `stripe_p_key` varchar(255) DEFAULT '',
  `stripe_currency` varchar(255) DEFAULT 'USD',
  `bank_transfer` int(11) DEFAULT '0',
  `bank_transfer_text` longtext NOT NULL,
  `estimate_terms` longtext NOT NULL,
  `estimate_prefix` varchar(250) DEFAULT 'EST',
  `estimate_pdf_template` varchar(250) DEFAULT 'templates/estimate/blueline',
  `invoice_pdf_template` varchar(250) DEFAULT 'templates/invoice/blueline',
  `second_tax` varchar(5) DEFAULT '',
  `estimate_mail_subject` varchar(255) DEFAULT 'New Estimate #{estimate_id}',
  `money_format` int(20) unsigned NOT NULL DEFAULT '1',
  `money_currency_position` int(20) unsigned NOT NULL DEFAULT '1',
  `pdf_font` varchar(255) DEFAULT 'NotoSans',
  `pdf_path` int(10) unsigned NOT NULL DEFAULT '1',
  `registration` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO core (`id`, `version`, `domain`, `email`, `company`, `tax`, `currency`, `autobackup`, `cronjob`, `last_cronjob`, `last_autobackup`, `invoice_terms`, `company_reference`, `project_reference`, `invoice_reference`, `subscription_reference`, `ticket_reference`, `date_format`, `date_time_format`, `invoice_mail_subject`, `pw_reset_mail_subject`, `pw_reset_link_mail_subject`, `credentials_mail_subject`, `notification_mail_subject`, `language`, `invoice_address`, `invoice_city`, `invoice_contact`, `invoice_tel`, `subscription_mail_subject`, `logo`, `template`, `paypal`, `paypal_currency`, `paypal_account`, `invoice_logo`, `pc`, `vat`, `ticket_email`, `ticket_default_owner`, `ticket_default_queue`, `ticket_default_type`, `ticket_default_status`, `ticket_config_host`, `ticket_config_login`, `ticket_config_pass`, `ticket_config_port`, `ticket_config_ssl`, `ticket_config_email`, `ticket_config_flags`, `ticket_config_search`, `ticket_config_timestamp`, `ticket_config_mailbox`, `ticket_config_delete`, `ticket_config_active`, `ticket_config_imap`, `stripe`, `stripe_key`, `stripe_p_key`, `stripe_currency`, `bank_transfer`, `bank_transfer_text`, `estimate_terms`, `estimate_prefix`, `estimate_pdf_template`, `invoice_pdf_template`, `second_tax`, `estimate_mail_subject`, `money_format`, `money_currency_position`, `pdf_font`, `pdf_path`, `registration`) VALUES ('1', '2.3.5', 'http://central.websitego.com.br', 'contato@websitego.com.br', 'Central Website GO', '0', 'R$', '1', '1', '1503536678', '1503536682', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '41059', '51020', '31067', '61004', '10003', 'd/m/Y', 'H:i', 'Nova fatura', 'Password Reset', 'Password Reset', 'Login Details', 'Notification', 'portuguese', '27.760.132/0001-78', 'São Paulo SP', 'Website GO Serviços LTDA', '(11) 9 9242-9212', 'New Subscription', 'files/media/websitego-logo.png', 'blueline', '1', 'BRL', 'kaiqueexp@gmail.com', 'files/media/websitego-logo1.png', '', '', NULL, '11', '1', '1', 'new', 'email-ssl.com.br', 'contato@websitego.com.br', 'Welcome100%', '993', '1', 'contato@websitego.com.br', '/novalidate-cert', 'UNSEEN', '0', 'INBOX', '0', '1', '1', '0', '', '', 'BRL', '0', '<span style=\"font-weight: bold;\">Ag</span>: 2921<div><span style=\"font-weight: bold;\">Cc</span>: 35972-1</div><div><span style=\"font-weight: bold;\">Kaique </span>Paes Alves</div><div><span style=\"font-weight: bold;\">CPF</span>: 40716300869</div><div><span style=\"font-weight: bold;\">Banco Itau</span></div>', '', 'EST', 'templates/estimate/blueline', 'templates/invoice/blueline', '', 'New Estimate #{estimate_id}', '1', '1', 'NotoSans', '1', '1');


#
# TABLE STRUCTURE FOR: custom_quotation_requests
#

DROP TABLE IF EXISTS custom_quotation_requests;

CREATE TABLE `custom_quotation_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form` longtext NOT NULL,
  `custom_quotation_id` int(11) unsigned NOT NULL,
  `date` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: custom_quotations
#

DROP TABLE IF EXISTS custom_quotations;

CREATE TABLE `custom_quotations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT '',
  `formcontent` longtext NOT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `created` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO custom_quotations (`id`, `name`, `formcontent`, `inactive`, `user_id`, `created`) VALUES ('3', 'Formulário de cotação', '{\"fields\":[{\"label\":\"Seu Nome\",\"field_type\":\"text\",\"required\":true,\"field_options\":{\"size\":\"small\"},\"cid\":\"c2\"},{\"label\":\"CPF/CNPJ\",\"field_type\":\"text\",\"required\":false,\"field_options\":{\"size\":\"small\"},\"cid\":\"c6\"},{\"label\":\"Telefone\",\"field_type\":\"text\",\"required\":true,\"field_options\":{\"size\":\"small\"},\"cid\":\"c10\"},{\"label\":\"Seu domínio\",\"field_type\":\"text\",\"required\":false,\"field_options\":{\"size\":\"small\",\"description\":\"ex: www.websitego.com.br\"},\"cid\":\"c16\"},{\"label\":\"E-mail\",\"field_type\":\"email\",\"required\":true,\"field_options\":{},\"cid\":\"c20\"},{\"label\":\"Tem loja física?\",\"field_type\":\"radio\",\"required\":true,\"field_options\":{\"options\":[{\"label\":\"Sim\",\"checked\":false},{\"label\":\"Não\",\"checked\":false}]},\"cid\":\"c24\"},{\"label\":\"Descreva qual serviço deseja\",\"field_type\":\"paragraph\",\"required\":true,\"field_options\":{\"size\":\"small\",\"description\":\"\"},\"cid\":\"c32\"}]}', '0', '9', '0');
INSERT INTO custom_quotations (`id`, `name`, `formcontent`, `inactive`, `user_id`, `created`) VALUES ('4', 'Contratação hospedagem', '{\"fields\":[{\"label\":\"Nome completo:\",\"field_type\":\"text\",\"required\":true,\"field_options\":{\"size\":\"small\"},\"cid\":\"c5\"},{\"label\":\"E-mail:\",\"field_type\":\"email\",\"required\":true,\"field_options\":{},\"cid\":\"c13\"},{\"label\":\"Telefone:\",\"field_type\":\"text\",\"required\":true,\"field_options\":{\"size\":\"small\"},\"cid\":\"c17\"},{\"label\":\"Hospedagem:\",\"field_type\":\"radio\",\"required\":true,\"field_options\":{\"options\":[{\"label\":\"Basic\",\"checked\":false},{\"label\":\"Plus\",\"checked\":true},{\"label\":\"Max\",\"checked\":false},{\"label\":\"Somente dúvidas\",\"checked\":false}]},\"cid\":\"c10\"}]}', '0', '10', '0');


#
# TABLE STRUCTURE FOR: expenses
#

DROP TABLE IF EXISTS expenses;

CREATE TABLE `expenses` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(250) DEFAULT '',
  `type` varchar(250) DEFAULT '',
  `category` varchar(250) DEFAULT '',
  `date` varchar(250) DEFAULT '',
  `currency` varchar(250) DEFAULT '',
  `value` float DEFAULT '0',
  `vat` varchar(250) DEFAULT '',
  `reference` varchar(250) DEFAULT '',
  `project_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rebill` int(20) unsigned NOT NULL DEFAULT '0',
  `invoice_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `attachment` varchar(250) DEFAULT '',
  `attachment_description` varchar(250) DEFAULT '',
  `recurring` varchar(250) DEFAULT '',
  `recurring_until` varchar(250) DEFAULT '',
  `user_id` int(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO expenses (`id`, `description`, `type`, `category`, `date`, `currency`, `value`, `vat`, `reference`, `project_id`, `rebill`, `invoice_id`, `attachment`, `attachment_description`, `recurring`, `recurring_until`, `user_id`) VALUES ('2', '3 Crachás', 'payment', 'Marketing - ', '2017-08-16', 'R$', '51', '', '', '0', '0', '0', 'f4bb817e2ec1e34fed758e4bb3736d57.jpeg', 'Comprovante de Pagamento', '', '', '11');
INSERT INTO expenses (`id`, `description`, `type`, `category`, `date`, `currency`, `value`, `vat`, `reference`, `project_id`, `rebill`, `invoice_id`, `attachment`, `attachment_description`, `recurring`, `recurring_until`, `user_id`) VALUES ('3', 'Registro de Domínio - websitego.com.br', 'payment', 'Web Hosting', '2017-09-16', 'R$', '40', '', '', '0', '0', '0', '', '', '', '', '11');
INSERT INTO expenses (`id`, `description`, `type`, `category`, `date`, `currency`, `value`, `vat`, `reference`, `project_id`, `rebill`, `invoice_id`, `attachment`, `attachment_description`, `recurring`, `recurring_until`, `user_id`) VALUES ('4', 'Registro de Domínio - vbarquiteturainteriores.com.br', 'payment', 'Web Hosting', '2017-09-27', 'R$', '40', '', '', '0', '0', '0', '', '', '', '', '11');
INSERT INTO expenses (`id`, `description`, `type`, `category`, `date`, `currency`, `value`, `vat`, `reference`, `project_id`, `rebill`, `invoice_id`, `attachment`, `attachment_description`, `recurring`, `recurring_until`, `user_id`) VALUES ('5', '3 Camisetas Website GO -', 'payment', 'Marketing - ', '2017-10-16', 'R$', '209.71', '', '', '0', '0', '0', '', '', '', '', '11');
INSERT INTO expenses (`id`, `description`, `type`, `category`, `date`, `currency`, `value`, `vat`, `reference`, `project_id`, `rebill`, `invoice_id`, `attachment`, `attachment_description`, `recurring`, `recurring_until`, `user_id`) VALUES ('6', 'Registro de Domínio - kingyotemakeria.com.br', 'payment', 'Web Hosting', '2017-10-24', 'R$', '40', '', '', '0', '0', '0', '', '', '', '', '11');
INSERT INTO expenses (`id`, `description`, `type`, `category`, `date`, `currency`, `value`, `vat`, `reference`, `project_id`, `rebill`, `invoice_id`, `attachment`, `attachment_description`, `recurring`, `recurring_until`, `user_id`) VALUES ('7', 'Indicação vbarquitetura', 'payment', 'Marketing - ', '2017-11-13', 'R$', '50', '', '', '0', '0', '0', 'a24ecae812d86b633d72b2a28a85e490.jpeg', 'Juros de 7,50', '', '', '11');
INSERT INTO expenses (`id`, `description`, `type`, `category`, `date`, `currency`, `value`, `vat`, `reference`, `project_id`, `rebill`, `invoice_id`, `attachment`, `attachment_description`, `recurring`, `recurring_until`, `user_id`) VALUES ('8', 'Desenvolvimento Logo Kingyotemakeria', 'payment', 'Web Hosting', '2017-12-05', 'R$', '80', '', '', '19', '0', '0', '', '', '', '', '11');
INSERT INTO expenses (`id`, `description`, `type`, `category`, `date`, `currency`, `value`, `vat`, `reference`, `project_id`, `rebill`, `invoice_id`, `attachment`, `attachment_description`, `recurring`, `recurring_until`, `user_id`) VALUES ('9', 'PABX Virtual', 'payment', 'Accommodation', '2017-12-09', 'R$', '59.9', '', '', '0', '0', '0', '', '', '', '', '11');
INSERT INTO expenses (`id`, `description`, `type`, `category`, `date`, `currency`, `value`, `vat`, `reference`, `project_id`, `rebill`, `invoice_id`, `attachment`, `attachment_description`, `recurring`, `recurring_until`, `user_id`) VALUES ('10', 'Pagamento Juliany', 'payment', 'Subscriptions', '2017-12-15', 'R$', '100', '', '', '0', '0', '0', '', '', '', '', '11');
INSERT INTO expenses (`id`, `description`, `type`, `category`, `date`, `currency`, `value`, `vat`, `reference`, `project_id`, `rebill`, `invoice_id`, `attachment`, `attachment_description`, `recurring`, `recurring_until`, `user_id`) VALUES ('11', 'Felipe Palma - Jacquet', 'payment', 'Marketing - ', '2017-12-21', 'R$', '3600', '', '', '0', '0', '0', '', '', '', '', '11');
INSERT INTO expenses (`id`, `description`, `type`, `category`, `date`, `currency`, `value`, `vat`, `reference`, `project_id`, `rebill`, `invoice_id`, `attachment`, `attachment_description`, `recurring`, `recurring_until`, `user_id`) VALUES ('12', 'Pagamento para Lucas', 'payment', 'Marketing - ', '2017-12-27', 'R$', '50', '', '', '0', '0', '0', '', '', '', '', '11');
INSERT INTO expenses (`id`, `description`, `type`, `category`, `date`, `currency`, `value`, `vat`, `reference`, `project_id`, `rebill`, `invoice_id`, `attachment`, `attachment_description`, `recurring`, `recurring_until`, `user_id`) VALUES ('14', 'Registro de domínio - consorciovolkswagenonline.com.br', 'payment', 'Web Hosting', '2018-01-16', 'R$', '40', '', '', '0', '0', '0', '', '', '', '', '11');
INSERT INTO expenses (`id`, `description`, `type`, `category`, `date`, `currency`, `value`, `vat`, `reference`, `project_id`, `rebill`, `invoice_id`, `attachment`, `attachment_description`, `recurring`, `recurring_until`, `user_id`) VALUES ('15', 'Registro de domínio - consorciovwdefabrica.com.br', 'payment', 'Web Hosting', '2018-01-16', 'R$', '40', '', '', '0', '0', '0', '', '', '', '', '11');
INSERT INTO expenses (`id`, `description`, `type`, `category`, `date`, `currency`, `value`, `vat`, `reference`, `project_id`, `rebill`, `invoice_id`, `attachment`, `attachment_description`, `recurring`, `recurring_until`, `user_id`) VALUES ('16', 'Novos Cartões WebsiteGO', 'payment', 'Marketing - ', '2018-01-30', 'R$', '170', '', '', '0', '0', '0', '', '', '', '', '11');
INSERT INTO expenses (`id`, `description`, `type`, `category`, `date`, `currency`, `value`, `vat`, `reference`, `project_id`, `rebill`, `invoice_id`, `attachment`, `attachment_description`, `recurring`, `recurring_until`, `user_id`) VALUES ('17', 'Chip - WebsiteGO', 'payment', 'Marketing - ', '2018-02-02', 'R$', '20', '', '', '0', '0', '0', '', '', '', '', '11');
INSERT INTO expenses (`id`, `description`, `type`, `category`, `date`, `currency`, `value`, `vat`, `reference`, `project_id`, `rebill`, `invoice_id`, `attachment`, `attachment_description`, `recurring`, `recurring_until`, `user_id`) VALUES ('18', 'Anúncios / Facebook / Instagram / Adwords', 'payment', 'Marketing - ', '2018-02-02', 'R$', '150', '', '', '0', '0', '0', '', '', '', '', '11');


#
# TABLE STRUCTURE FOR: invoice_has_items
#

DROP TABLE IF EXISTS invoice_has_items;

CREATE TABLE `invoice_has_items` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `amount` char(11) DEFAULT NULL,
  `description` mediumtext,
  `value` float DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `type` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8;

INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('44', '29', '0', '1', '', '25', 'Hospedagem Basic - MySQL incluso - 5 Caixas postais', 'Hospedagem');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('45', '30', '17', '1', 'Plano de hospedagem', '25', 'Hospedagem Basic - MySQL incluso - 5 Caixas p', 'Hospedagem');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('46', '34', '17', '1', ' - MySQL incluso \n - 5 Caixas postais\n ', '25', 'Hospedagem Basic', 'Hospedagem de Sites ');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('47', '35', '17', '1', ' - MySQL incluso \n - 5 Caixas postais\n ', '25', 'Hospedagem Basic', 'Hospedagem de Sites ');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('53', '34', '0', '1', '', '100', 'Site MontPiscinas 1/2', 'Desenvolvimento de sites');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('54', '35', '0', '1', '', '100', 'Site - monpiscinas 2x2', '');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('55', '35', '0', '1', 'Adição de Chat Online - TomTicket', '10', 'Chat - Website', '');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('56', '36', '17', '1', ' - MySQL incluso \n - 5 Caixas postais\n ', '25', 'Hospedagem Basic', 'Hospedagem de Sites ');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('57', '36', '20', '1', '- Chat Online - Hospedagem', '10', 'Chat Online', 'Site');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('58', '37', '0', '1', '', '1', 'teste', '');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('59', '38', '0', '1', '', '35', 'Hospedagem Basic - MySQL incluso - 5 Caixas postais', '');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('60', '38', '0', '1', '', '100', 'Desenvolvimento de sites', '');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('61', '39', '20', '1', '- Chat Online - Hospedagem', '10', 'Chat Online', 'Site');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('62', '39', '17', '1', ' - MySQL incluso \n - 5 Caixas postais\n ', '25', 'Hospedagem Basic', 'Hospedagem de Sites ');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('63', '40', '18', '1', '', '40', 'Registro de domínio', 'Anual');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('64', '41', '21', '1', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n10 Caixas postais\n1 ano de Domínio grátis', '35', 'Hospedagem Plus', 'Hospedagem Plus');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('65', '42', '23', '1', '1/2\n\nValor cheio 200,00 R$', '100', 'Densenvolvimento de site ', 'Criação de Site ');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('66', '41', '23', '1', '1/02', '100', 'Densenvolvimento de site ', 'Criação de Site ');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('67', '43', '23', '1', 'Site: vbarquiteturainteriores.com.br', '100', 'Densenvolvimento de site ', 'Criação de Site ');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('68', '43', '21', '1', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n10 Caixas postais\n1 ano de Domínio grátis', '35', 'Hospedagem Plus', 'Hospedagem Plus');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('70', '44', '0', '1', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n5 Caixas Postais', '280', 'Hospedagem Anual - Basic - ', '');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('71', '44', '18', '1', 'Domínio kingyotemakeria.com.br', '40', 'Registro de domínio', 'Anual');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('72', '44', '0', '1', 'Página Inicial\nPágina de Contato\nIntegração com Redes sociais\nGaleria com até 6 imagens', '280', 'Site Básico - Anual ', '');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('73', '45', '17', '1', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n5 Caixas Postais', '25', 'Hospedagem Basic', 'Hospedagem Basic');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('74', '45', '20', '1', '- Chat Online - Hospedagem', '10', 'Chat Online', 'Site');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('75', '44', '24', '1', 'Desenvolvimento de logo Kingyo', '120', 'Logo', 'Marketing');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('76', '46', '24', '1', '', '120', 'Logo', 'Marketing');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('77', '46', '25', '1', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n10 Caixas postais\n1 ano de Domínio grátis', '280', 'Hospedagem Basic', 'Anual');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('78', '46', '28', '1', 'Página Inicial\nPágina de Contato\nIntegração com Redes sociais\nGaleria com até 12 imagens', '280', 'Site Básico ', 'Anual');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('79', '46', '18', '1', '', '40', 'Registro de domínio', 'Anual');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('81', '47', '32', '1', 'Desenvolvimento de site | jacquet.com.br', '6000', 'Desenvolvimento de site ', 'Projeto de desenvolvimento');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('82', '49', '21', '1', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n10 Caixas Postais\nAdministração de e-mail', '35', 'Hospedagem Plus', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('83', '50', '17', '1', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n5 Caixas Postais', '25', 'Hospedagem Basic', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('84', '50', '20', '1', '- Chat Online - Hospedagem', '10', 'Chat Online', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('85', '48', '25', '1', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n5 Caixas Postais', '280', 'Hospedagem Basic - Anual', 'Anual');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('86', '48', '28', '1', 'Página Inicial\nPágina de Contato\nIntegração com Redes sociais\nGaleria com até 12 imagens', '280', 'Site Básico  - Anual', 'Anual');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('87', '48', '24', '1', 'Logo:', '120', 'Logo', 'Sem parcelas');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('88', '48', '18', '1', '', '40', 'Registro de domínio', 'Anual');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('89', '51', '31', '2', 'Parcela Mensal para desenvolvimento de sites - renemuniz.net\nSite Avançado\n\n8x 200,00\n', '100', 'Desenvolvimento de site ', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('91', '52', '20', '1', '- Chat Online - Hospedagem', '10', 'Chat Online', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('92', '52', '17', '1', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n5 Caixas Postais', '25', 'Hospedagem Basic', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('93', '53', '21', '1', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n10 Caixas Postais\nAdministração de e-mail', '35', 'Hospedagem Plus', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('94', '54', '17', '1', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n5 Caixas Postais', '25', 'Hospedagem Basic', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('95', '56', '18', '1', '', '50', 'Registro de domínio', 'Anual');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('96', '56', '18', '1', '', '50', 'Registro de domínio', 'Anual');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('97', '57', '21', '1', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n10 Caixas Postais\nAdministração de e-mail', '35', 'Hospedagem Plus', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('98', '58', '21', '1', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n10 Caixas Postais\nAdministração de e-mail', '35', 'Hospedagem Plus', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('100', '59', '33', '1', '', '380', 'Parcelas', 'Desenvolvimento de Site');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('101', '60', '34', '1', '', '600', 'Desenvolvimento', 'Parcelas / Desenvolvimento');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('102', '61', '21', '1', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n10 Caixas Postais\nAdministração de e-mail', '35', 'Hospedagem Plus', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('103', '62', '21', '1', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n10 Caixas Postais\nAdministração de e-mail', '35', 'Hospedagem Plus', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('104', '63', '34', '1', '', '600', 'Desenvolvimento', 'Parcelas / Desenvolvimento');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('105', '63', '17', '1', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n5 Caixas Postais', '25', 'Hospedagem Basic', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('106', '64', '31', '1', 'Parcela Mensal para desenvolvimento de sites -\n\nSite Básico\nSite Premium\nSite Avançado\n', '100', 'Desenvolvimento de site ', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('107', '64', '31', '1', 'Parcela Mensal para desenvolvimento de sites -\n\nSite Básico\nSite Premium\nSite Avançado\n', '100', 'Desenvolvimento de site ', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('108', '65', '29', '1', 'Página Inicial\nPágina de Sobre\nPágina de Contato\nGaleria com até 24 imagens\nIntegração com Redes sociais', '470', 'Site Premium - Anual', 'Anual');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('109', '66', '33', '1', '', '380', 'Parcelas', 'Desenvolvimento de Site');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('110', '67', '18', '1', '', '50', 'Registro de domínio', 'Anual');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('111', '68', '18', '1', '', '50', 'Registro de domínio', 'Anual');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('114', '69', '24', '1', 'Desenvolvimento Logo:', '200', 'Logo', 'Sem parcelas');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('115', '70', '34', '1', '', '600', 'Desenvolvimento', 'Parcelas / Desenvolvimento');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('117', '71', '0', '1', '', '150', 'Marketing Digital', '');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('118', '72', '21', '1', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n10 Caixas Postais\nAdministração de e-mail', '35', 'Hospedagem Plus', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('119', '73', '21', '1', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n10 Caixas Postais\nAdministração de e-mail', '35', 'Hospedagem Plus', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('120', '74', '17', '1', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n5 Caixas Postais', '25', 'Hospedagem Basic', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('121', '75', '31', '1', 'Parcela Mensal para desenvolvimento de sites -\n\nSite Básico\nSite Premium\nSite Avançado\n', '100', 'Desenvolvimento de site ', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('122', '75', '31', '1', 'Parcela Mensal para desenvolvimento de sites -\n\nSite Básico\nSite Premium\nSite Avançado\n', '100', 'Desenvolvimento de site ', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('124', '77', '0', '1', 'Desenvolvimento do site', '630', 'Desenvolvimento', '');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('125', '77', '24', '1', 'Desenvolvimento Logo:', '200', 'Logo', 'Sem parcelas');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('126', '78', '24', '1', 'Desenvolvimento Logo:', '200', 'Logo', 'Sem parcelas');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('128', '78', '0', '1', '', '630', 'Desenvolvimento - Site', '');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('129', '79', '18', '1', '', '50', 'Registro de domínio', 'Anual');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('130', '77', '17', '1', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n5 Caixas Postais', '30', 'Hospedagem Basic', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('131', '78', '17', '1', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n3 Caixas Postais', '30', 'Hospedagem Basic', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('132', '80', '0', '1', 'Início de Desenvolvimento - cmebrio \nParcela 1/04', '300', 'Desenvolvimento - Site', '');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('133', '81', '20', '1', '- Chat Online - Hospedagem', '10', 'Chat Online', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('134', '82', '0', '1', 'Google Adwords - Anúncio Impulsionado - consorciovwdefabrica.com.br', '145', 'Google Adwords - Anúncio Impulsionado', '');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('135', '82', '0', '1', 'Produção de 4 banners por mês.\n1 Banner Semanal \n\nInício - 17/04/2018\nFim - 17/05/2018', '30', 'Facebook - Mídias Sociais', '');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('136', '76', '0', '1', '02/04 - 446 - Desenvolvimento Web - LogoMarca', '446', '02/04 Desenvolvimento', '');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('137', '83', '0', '1', 'Parcela 02/04 - Desenvolvimento Web - Logomarca', '446', '02/04 Desenvolvimento', '');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('138', '86', '17', '1', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n3 Caixas Postais', '30', 'Hospedagem Basic', 'Mensal');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('140', '85', '0', '1', 'Multiplataforma Suporte Integrado Site Online 24 Horas 10 Caixas Postais', '35', 'Hospedagem', '');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('141', '84', '17', '1', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n3 Caixas Postais', '35', 'Hospedagem', '');
INSERT INTO invoice_has_items (`id`, `invoice_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('142', '87', '0', '1', 'Registro de domínio\nDesenvolvimento - Site', '250', 'Desenvolvimento - Site', '');


#
# TABLE STRUCTURE FOR: invoices
#

DROP TABLE IF EXISTS invoices;

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` int(11) DEFAULT NULL,
  `company_id` int(11) NOT NULL,
  `status` varchar(50) DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `issue_date` varchar(20) DEFAULT NULL,
  `due_date` varchar(20) DEFAULT NULL,
  `sent_date` varchar(20) DEFAULT NULL,
  `paid_date` varchar(20) DEFAULT NULL,
  `terms` mediumtext,
  `discount` varchar(50) DEFAULT '0',
  `subscription_id` varchar(50) DEFAULT '0',
  `project_id` int(11) DEFAULT '0',
  `tax` varchar(255) DEFAULT '',
  `estimate` int(11) DEFAULT '0',
  `estimate_status` varchar(255) DEFAULT '0',
  `estimate_accepted_date` varchar(255) DEFAULT '0',
  `estimate_sent` varchar(255) DEFAULT '0',
  `sum` float DEFAULT '0',
  `second_tax` varchar(5) DEFAULT '',
  `estimate_reference` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8;

INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('29', '31001', '26', 'Paid', 'R$', '2017-06-06', '2017-06-10', NULL, '2017-06-14', 'Thank you for your business. We do expect payment within {due_date}, so please process this invoice within that time.', '', '0', '0', '0', '0', '0', '0', '0', '25', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('34', '31006', '26', 'Paid', 'R$', '2017-07-05', '2017-07-10', NULL, '2017-07-11', '<div><div>Agradecemos por escolher a WebsiteGo. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '1,00', '0', '16', '0', '0', '0', '0', '0', '124', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('35', '31013', '26', 'Paid', 'R$', '2017-08-05', '2017-08-10', NULL, '2017-08-15', '<div><div>Agradecemos por escolher a WebsiteGo. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '1,00', '0', '16', '0', '0', '0', '0', '0', '134', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('36', '31014', '26', 'Paid', 'R$', '2017-09-05', '2017-09-10', NULL, '2017-09-13', '<div><div>Agradecemos por escolher a WebsiteGo. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '1.00', '0', '0', '0', '0', '0', '0', '0', '34', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('39', '31017', '26', 'Paid', 'R$', '2017-10-05', '2017-10-10', NULL, '2017-10-12', '<div><div>Agradecemos por escolher a WebsiteGo. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '1', '0', '0', '0', '0', '0', '0', '0', '34', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('41', '31019', '44', 'Paid', 'R$', '2017-10-05', '2017-10-10', NULL, '2017-10-16', '<div><div>Agradecemos por escolher a WebsiteGO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '18', '0', '0', '0', '0', '0', '135', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('43', '31021', '44', 'Paid', 'R$', '2017-11-05', '2017-11-10', NULL, '2017-11-14', '<div><div>Agradecemos por escolher a WebsiteGo. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '1.00', '0', '18', '0', '0', '0', '0', '0', '134', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('45', '31023', '26', 'Paid', 'R$', '2017-11-05', '2017-11-10', NULL, '2017-11-13', '<div><div>Agradecemos por escolher a WebsiteGo. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '1', '0', '0', '0', '0', '0', '0', '0', '34', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('46', '31024', '49', 'Paid', 'R$', '2017-11-05', '2017-11-10', NULL, '2017-11-13', '<div><div>Agradecemos por escolher a WebsiteGo. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div><div><span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\"><br></span></div><div><span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">Realizado o desconto de 30% conforme contrato.</span></div><div><span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\"><br></span></div><div><span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">Valor pago na entrega do projeto R$ 504,00</span></div>', '504', '0', '19', '0', '0', '0', '0', '0', '216', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('47', '31025', '50', 'Paid', 'R$', '2017-12-13', '2017-12-20', NULL, '2017-12-20', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '21', '0', '0', '0', '0', '0', '6000', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('48', '31026', '49', 'Paid', 'R$', '2017-12-18', '2017-12-22', NULL, '2017-12-27', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '216.00', '0', '19', '0', '0', '0', '0', '0', '504', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('49', '31027', '44', 'Paid', 'R$', '2017-12-05', '2017-12-10', NULL, '2017-12-18', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '0', '0', '0', '0', '0', '0', '35', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('50', '31028', '26', 'Paid', 'R$', '2017-12-05', '2017-12-10', NULL, '2017-12-18', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '0', '0', '0', '0', '0', '0', '35', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('52', '31030', '26', 'Paid', 'R$', '2018-01-05', '2018-01-10', NULL, '2018-01-17', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '0', '0', '0', '0', '0', '0', '35', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('53', '31031', '44', 'Paid', 'R$', '2018-01-05', '2018-01-10', NULL, '2018-01-12', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '0', '0', '0', '0', '0', '0', '35', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('54', '31032', '49', 'Open', 'R$', '2018-12-05', '2018-12-10', NULL, NULL, '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '0', '0', '0', '0', '0', '0', '25', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('56', '31034', '56', 'Paid', 'R$', '2018-01-20', '2018-01-26', NULL, '2018-02-02', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '0', '0', '0', '0', '0', '0', '100', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('57', '31035', '26', 'Paid', 'R$', '2018-02-05', '2018-02-10', NULL, '2018-02-15', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '0', '0', '0', '0', '0', '0', '35', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('58', '31036', '44', 'Paid', 'R$', '2018-02-05', '2018-02-10', NULL, '2018-03-04', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '0', '0', '0', '0', '0', '0', '35', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('59', '31037', '57', 'Paid', 'R$', '2018-02-05', '2018-02-10', NULL, '2018-02-15', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '0', '0', '0', '0', '0', '0', '380', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('60', '31038', '56', 'Paid', 'R$', '2018-02-05', '2018-02-14', NULL, '2018-03-04', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '0', '0', '0', '0', '0', '0', '600', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('61', '31039', '26', 'Paid', 'R$', '2018-03-05', '2018-03-10', NULL, '2018-03-13', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '0', '0', '0', '0', '0', '0', '35', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('62', '31040', '44', 'Paid', 'R$', '2018-03-05', '2018-03-10', NULL, '2018-03-26', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '0', '0', '0', '0', '0', '0', '35', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('63', '31041', '56', 'Paid', 'R$', '2018-03-05', '2018-03-10', NULL, '2018-03-21', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '23', '0', '0', '0', '0', '0', '625', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('64', '31042', '51', 'Paid', 'R$', '2018-03-05', '2018-03-10', NULL, '2018-03-16', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '22', '0', '0', '0', '0', '0', '200', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('65', '31043', '57', 'Open', 'R$', '2018-04-05', '2018-05-10', NULL, NULL, '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '24', '0', '24', '0', '0', '0', '0', '0', '446', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('66', '31044', '58', 'Sent', 'R$', '2018-03-05', '2018-03-10', NULL, NULL, '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '20', '0', '0', '0', '0', '0', '0', '0', '360', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('67', '31045', '58', 'Sent', 'R$', '2018-03-05', '2018-03-10', NULL, NULL, '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '0', '0', '0', '0', '0', '0', '50', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('68', '31046', '59', 'Paid', 'R$', '2018-03-17', '2018-03-20', NULL, '2018-03-21', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '28', '0', '0', '0', '0', '0', '50', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('70', '31048', '59', 'Paid', 'R$', '2018-03-17', '2018-03-20', NULL, '2018-03-21', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '60', '0', '28', '0', '0', '0', '0', '0', '540', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('72', '31050', '26', 'Paid', 'R$', '2018-04-10', '2018-04-10', NULL, '2018-04-15', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '0', '0', '0', '0', '0', '0', '35', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('73', '31051', '44', 'Paid', 'R$', '2018-04-10', '2018-04-10', NULL, '2018-04-15', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '0', '0', '0', '0', '0', '0', '35', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('74', '31052', '56', 'Paid', 'R$', '2018-04-10', '2018-04-10', NULL, '2018-04-19', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '0', '0', '0', '0', '0', '0', '25', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('75', '31053', '51', 'Paid', 'R$', '2018-04-10', '2018-04-10', NULL, '2018-04-15', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '22', '0', '0', '0', '0', '0', '200', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('77', '31055', '59', 'Sent', 'R$', '2018-05-10', '2018-05-10', NULL, NULL, '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '100', '0', '28', '0', '0', '0', '0', '0', '760', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('78', '31056', '59', 'Paid', 'R$', '2018-04-10', '2018-04-10', NULL, '2018-05-04', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '100', '0', '28', '0', '0', '0', '0', '0', '760', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('79', '31057', '59', 'Paid', 'R$', '2018-04-10', '2018-04-10', NULL, '2018-05-04', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '28', '0', '0', '0', '0', '0', '50', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('80', '31058', '62', 'Paid', 'R$', '2018-04-16', '2018-04-19', '2018-04-16', '2018-04-22', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '0', '0', '0', '0', '0', '0', '300', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('82', '31060', '56', 'Paid', 'R$', '2018-04-10', '2018-04-20', NULL, '2018-04-19', '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '0', '0', '0', '0', '0', '0', '175', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('83', '31061', '57', 'Open', 'R$', '2018-05-10', '2018-05-10', NULL, NULL, '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '24', '0', '0', '0', '0', '0', '446', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('84', '31062', '26', 'Open', 'R$', '2018-05-10', '2018-05-10', NULL, NULL, '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '0', '0', '0', '0', '0', '0', '35', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('85', '31063', '44', 'Open', 'R$', '2018-05-10', '2018-05-10', NULL, NULL, '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '0', '0', '0', '0', '0', '0', '35', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('86', '31064', '56', 'Open', 'R$', '2018-05-10', '2018-05-10', NULL, NULL, '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '5', '0', '0', '0', '0', '0', '0', '0', '25', '', '');
INSERT INTO invoices (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `due_date`, `sent_date`, `paid_date`, `terms`, `discount`, `subscription_id`, `project_id`, `tax`, `estimate`, `estimate_status`, `estimate_accepted_date`, `estimate_sent`, `sum`, `second_tax`, `estimate_reference`) VALUES ('87', '31065', '63', 'Open', 'R$', '2018-05-09', '2018-05-09', NULL, NULL, '<div><div>Agradecemos por escolher a Website GO. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '0', '0', '0', '0', '0', '0', '250', '', '');


#
# TABLE STRUCTURE FOR: items
#

DROP TABLE IF EXISTS items;

CREATE TABLE `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `value` float DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `description` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('17', 'Hospedagem Basic', '30', 'Mensal', '0', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n3 Caixas Postais');
INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('18', 'Registro de domínio', '50', 'Anual', '0', '');
INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('19', 'Registro de domínio', '40', 'Anual', '1', 'divalingerie.com.br');
INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('20', 'Chat Online', '10', 'Mensal', '0', '- Chat Online - Hospedagem');
INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('21', 'Hospedagem Plus', '50', 'Mensal', '0', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n10 Caixas Postais\nAdministração de e-mail');
INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('22', 'Hospedagem Max', '70', 'Mensal', '0', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n15 Caixas postais\n1 ano de Domínio grátis\nAdministração de e-mail');
INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('23', 'Desenvolvimento de site ', '100', 'Mensal', '1', 'Site: ?');
INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('24', 'Logo', '200', 'Sem parcelas', '0', 'Desenvolvimento Logo:');
INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('25', 'Hospedagem Basic - Anual', '280', 'Anual', '0', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n5 Caixas Postais');
INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('26', 'Hospedagem Plus - Anual', '400', 'Anual', '0', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n10 Caixas Postais\nAdministração de e-mail');
INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('27', 'Hospedagem Max - Anual', '560', 'Anual', '0', 'Multiplataforma\nSuporte Integrado\nSite Online 24 Horas\n15 Caixas postais\n1 ano de Domínio grátis\nAdministração de e-mail');
INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('28', 'Site Básico  - Anual', '280', 'Anual', '0', 'Página Inicial\nPágina de Contato\nIntegração com Redes sociais\nGaleria com até 12 imagens');
INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('29', 'Site Premium - Anual', '470', 'Anual', '0', 'Página Inicial\nPágina de Sobre\nPágina de Contato\nGaleria com até 24 imagens\nIntegração com Redes sociais');
INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('30', 'Site Avançado - Anual', '760', 'Anual', '0', 'Página Inicial\nPágina de Sobre\nPágina de Contato\nGaleria com até 48 imagens\nIntegração com Redes sociais\nSEO - Indexação no google');
INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('31', 'Desenvolvimento de site ', '100', 'Mensal', '1', 'Parcela Mensal para desenvolvimento de sites -\n\nSite Básico\nSite Premium\nSite Avançado\n');
INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('32', 'Desenvolvimento de site ', '6000', 'Projeto de desenvolvimento', '1', 'Desenvolvimento de site | jacquet.com.br');
INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('33', 'Parcelas', '380', 'Desenvolvimento de Site', '0', '');
INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('34', 'Desenvolvimento', '600', 'Parcelas / Desenvolvimento', '1', '');
INSERT INTO items (`id`, `name`, `value`, `type`, `inactive`, `description`) VALUES ('35', 'Adiantamento - Site', '600', 'Desenvolvimento', '1', '30% desenvolvimento de site.');


#
# TABLE STRUCTURE FOR: messages
#

DROP TABLE IF EXISTS messages;

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT '0',
  `media_id` int(11) DEFAULT '0',
  `from` varchar(120) DEFAULT NULL,
  `text` text,
  `datetime` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: migrations
#

DROP TABLE IF EXISTS migrations;

CREATE TABLE `migrations` (
  `version` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: modules
#

DROP TABLE IF EXISTS modules;

CREATE TABLE `modules` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT '0',
  `link` varchar(250) DEFAULT '0',
  `type` varchar(250) DEFAULT '0',
  `icon` varchar(150) DEFAULT NULL,
  `sort` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8;

INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('1', 'Dashboard', 'dashboard', 'main', 'icon-th', '1');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('2', 'Messages', 'messages', 'main', 'icon-inbox', '2');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('3', 'Projects', 'projects', 'main', 'icon-briefcase', '3');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('4', 'Clients', 'clients', 'main', 'icon-user', '4');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('5', 'Invoices', 'invoices', 'main', 'icon-list-alt', '5');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('6', 'Items', 'items', 'main', 'icon-file', '7');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('7', 'Quotations', 'quotations', 'main', 'icon-list-alt', '8');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('8', 'Subscriptions', 'subscriptions', 'main', 'icon-calendar', '6');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('9', 'Settings', 'settings', 'main', 'icon-cog', '20');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('10', 'QuickAccess', 'quickaccess', 'widget', NULL, '50');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('11', 'User Online', 'useronline', 'widget', NULL, '51');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('12', 'Projects', 'cprojects', 'client', 'icon-briefcase', '2');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('13', 'Invoices', 'cinvoices', 'client', 'icon-list-alt', '3');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('14', 'Messages', 'cmessages', 'client', 'icon-inbox', '1');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('15', 'Subscriptions', 'csubscriptions', 'client', 'icon-calendar', '4');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('16', 'Tickets', 'tickets', 'main', 'icon-tag', '8');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('17', 'Tickets', 'ctickets', 'client', 'icon-tag', '4');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('18', 'Estimates', 'estimates', 'main', 'fa-files-o', '5');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('19', 'Expenses', 'expenses', 'main', 'fa-money', '5');
INSERT INTO modules (`id`, `name`, `link`, `type`, `icon`, `sort`) VALUES ('107', 'Estimates', 'cestimates', 'client', 'fa-files-o', '3');


#
# TABLE STRUCTURE FOR: privatemessages
#

DROP TABLE IF EXISTS privatemessages;

CREATE TABLE `privatemessages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(150) NOT NULL,
  `sender` varchar(250) NOT NULL,
  `recipient` varchar(250) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text,
  `time` varchar(100) NOT NULL,
  `conversation` varchar(32) DEFAULT NULL,
  `deleted` int(11) DEFAULT '0',
  `attachment` varchar(255) DEFAULT '',
  `attachment_link` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=160 DEFAULT CHARSET=utf8;

INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('127', 'Replied', 'u10', 'u11', 'Potencial Cliente', '<p>Boa tarde</p><p>Ligar para o cliente&nbsp;<span style=\"font-weight: bold;\">Roberto </span>do número&nbsp;<span style=\"text-decoration-line: underline;\">+55 11 94715-0373</span> pois ele deseja criar uma loja virtual com nós.</p><p>Verificar com o cliente como ele quer o site e preencher o formulário:</p><p>► https://gerenciador.websitego.com.br/quotation/qid/3</p><p>Att</p>', '2017-06-19 13:33', '0b85a8a2282450915512c88cf3c5b10e', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('128', 'New', 'u10', 'u12', 'Potencial Cliente', '<p>Boa tarde</p><p>Ligar para o cliente&nbsp;<span style=\"font-weight: bold;\">Roberto&nbsp;</span>do número&nbsp;<span style=\"text-decoration-line: underline;\">+55 11 94715-0373</span>&nbsp;pois ele deseja criar uma loja virtual com nós.</p><p>Verificar com o cliente como ele quer o site e preencher o formulário:</p><p>► https://gerenciador.websitego.com.br/quotation/qid/3</p><p>Att</p>', '2017-06-19 13:33', '8b7c6df9c467aa5615dfdc98dd4580b2', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('129', 'Read', 'u11', 'u10', 'Potencial Cliente', '<p>Liguei para o cliente, ficamos de combinar via Whats app e marcar um encontro.</p><p>Att.</p>', '2017-06-20 12:09', '0b85a8a2282450915512c88cf3c5b10e', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('130', 'Read', 'u11', 'c30', 'Renovar Conta no Iluria', '<p>Olá, Valdiva Batista Pereira.</p><p>Sua Loja virtual está <span style=\"font-weight: bold; color: rgb(255, 0, 0);\">Desativada</span> devido a pendência com a Iluria.</p><p>Acesse:&nbsp;http://admin.iluria.com/public/login.jsp</p><p><span style=\"font-weight: bold;\">Login:</span> diva@divalingerie.com.br</p><p><span style=\"font-weight: bold;\">Senha:</span> Senai115</p><p>E renove a sua assinatura pelo tempo que quiser.</p><p>Dúvidas estou a disposição.</p><p><br></p>', '2017-06-20 12:59', 'b3b433728ede238858f5c47874305c3f', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('131', 'Read', 'u11', 'u17', 'Comprar camiseta', '<p>Bom dia Victor.</p><p>Precisamos que realize a comprar uma <span style=\"font-weight: bold;\">Camiseta Polo&nbsp;</span>cor&nbsp;<span style=\"font-weight: bold;\">Preta</span></p><p>Do seu tamanho&nbsp;sem estampa toda lisa, para a produção da camiseta bordada, segue uma de exemplo em anexo.</p><p>Att.</p>', '2017-06-20 13:06', 'a3825ca1541a58aa03a359c18d9d1aed', '0', 'camiseta.jpg', '133c8eca1b29c0eb7abf54d3707bdbd7.jpg');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('132', 'Read', 'u10', 'c39', 'teste', 'teste', '2017-06-21 16:28', '545bb5e96eaa416e2c6193098024019c', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('133', 'Replied', 'u11', 'u10', 'Novo Template de site', '<p><dl class=\"plan-info-list\" style=\"border: 0px; margin: 2px; padding: 5px 5px 0px; font-size: 11px; outline: none; clear: both; color: rgb(0, 0, 0); font-family: Verdana, Helvetica, sans-serif; background-color: rgb(247, 247, 247);\"><dd style=\"border: 0px; margin-top: 5px; margin-right: 0px; margin-bottom: 5px; padding: 1px 1px 1px 10px; outline: none; vertical-align: top; display: inline-block; line-height: 15px; font-weight: bold; width: 568px;\">hm8227</dd></dl><hr style=\"height: 2px; background: url(&quot;/assets/lines-285073b2e777b4f8d75e8491abece55b.png&quot;) repeat-x rgb(247, 247, 247); border-top: 0px; margin: 0px; padding: 0px; font-size: 11px; outline: none; color: rgb(0, 0, 0); font-family: Verdana, Helvetica, sans-serif;\"><dl class=\"plan-info-list\" style=\"border: 0px; margin: 2px; padding: 5px 5px 0px; font-size: 11px; outline: none; clear: both; color: rgb(0, 0, 0); font-family: Verdana, Helvetica, sans-serif; background-color: rgb(247, 247, 247);\"><dd style=\"border: 0px; margin-top: 5px; margin-right: 0px; margin-bottom: 5px; padding: 1px 1px 1px 10px; outline: none; vertical-align: top; display: inline-block; line-height: 15px; font-weight: bold; width: 568px;\">freeair1</dd></dl></p><p><dl class=\"plan-info-list\" style=\"border: 0px; margin: 2px; padding: 5px 5px 0px; font-size: 11px; outline: none; clear: both; color: rgb(0, 0, 0); font-family: Verdana, Helvetica, sans-serif; background-color: rgb(247, 247, 247);\"><dd style=\"border: 0px; margin-top: 5px; margin-right: 0px; margin-bottom: 5px; padding: 1px 1px 1px 10px; outline: none; vertical-align: top; display: inline-block; line-height: 15px; font-weight: bold; width: 568px;\">Achei esse Template Interessante.<br></dd></dl></p><p><dl class=\"plan-info-list\" style=\"border: 0px; margin: 2px; padding: 5px 5px 0px; font-size: 11px; outline: none; clear: both; color: rgb(0, 0, 0); font-family: Verdana, Helvetica, sans-serif; background-color: rgb(247, 247, 247);\"><dd style=\"border: 0px; margin-top: 5px; margin-right: 0px; margin-bottom: 5px; padding: 1px 1px 1px 10px; outline: none; vertical-align: top; display: inline-block; line-height: 15px; font-weight: bold; width: 568px;\"><br></dd></dl></p>', '2017-06-25 17:53', 'c9a20460a8aa49eeebb4b3c6024e2165', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('134', 'Read', 'u10', 'u11', 'Novo Template de site', '<p>Pode deixar que amanhã eu vou ver.</p><p>Mais pra ajudar passa o domínio aí.</p>', '2017-06-25 21:57', 'c9a20460a8aa49eeebb4b3c6024e2165', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('135', 'Read', 'u11', 'u10', 'Dados de acesso montpsicinas', '<p style=\"margin-bottom: 10px; line-height: 22px;\">Boa Tarde Kaique, segue os dados.</p><p style=\"margin-bottom: 10px; line-height: 22px;\"><span style=\"background-color: yellow;\">FTP:</span></p><table class=\"tableList\" id=\"table_ftp_details\" style=\"background-color: rgb(255, 255, 255);\"><tbody><tr><td class=\"span7 noBorderRight txtLeft\"><span style=\"font-weight: 700;\">Host de FTP:&nbsp;</span><a href=\"ftp://montpiscinas1@ftp.montpiscinas.provisorio.ws/\" tabindex=\"3\" target=\"_blank\" title=\"ftp.montpiscinas.provisorio.ws\" data-ga-goal=\"Host de FTP\" data-ga-result=\"Nova Janela (Protocolo FTP - ftp://)\" data-ga-context=\"FTP\" style=\"color: rgb(68, 68, 68); line-height: 18px;\">ftp.montpiscinas.provisorio.ws</a></td><td class=\"span3\"></td></tr><tr><td class=\"span7 noBorderRight txtLeft\"><span style=\"font-weight: 700;\">Usuário de FTP:&nbsp;</span>montpiscinas1</td><td class=\"span3\"></td></tr><tr><td class=\"span7 noBorderRight txtLeft\"><p style=\"margin-bottom: 10px; line-height: 22px;\"><span style=\"font-weight: 700;\">Senha de FTP:&nbsp;</span>Senai115 &nbsp; &nbsp; &nbsp;&nbsp;</p><p style=\"margin-bottom: 10px; line-height: 22px;\"><br></p><p style=\"margin-bottom: 10px; line-height: 22px;\"><span style=\"background-color: yellow;\">BANCO:</span></p><p style=\"margin-bottom: 10px; line-height: 22px;\"><span style=\"font-weight: bold;\">Usuário:&nbsp;</span>montpiscinas02</p><p style=\"margin-bottom: 10px; line-height: 22px;\"><span style=\"background-color: transparent; font-weight: bold;\">Servidor:</span><span style=\"background-color: transparent;\">&nbsp;</span><span style=\"background-color: transparent;\">montpiscinas02.mysql.dbaas.com.br</span></p><p style=\"margin-bottom: 10px; line-height: 22px;\"><span style=\"font-size: 14px; font-weight: bold;\">Senha:</span><span style=\"font-size: 14px;\">&nbsp;Wsgo@1020</span></p><p style=\"margin-bottom: 10px; line-height: 22px;\"><span style=\"font-size: 14px;\"><br></span></p><p style=\"margin-bottom: 10px; line-height: 22px;\"><span style=\"font-size: 14px;\"><br></span></p><p style=\"margin-bottom: 10px; line-height: 22px;\"><span style=\"font-size: 14px;\">Te</span><span style=\"font-size: 14px;\">mplate do site:&nbsp;freeair.com.br</span></p><p style=\"margin-bottom: 10px; line-height: 22px;\"><span style=\"font-size: 14px;\">Servidor:&nbsp;hm8227</span></p><p style=\"margin-bottom: 10px; line-height: 22px;\"><span style=\"font-size: 14px;\">FTP:&nbsp;freeair1&nbsp;</span></p></td></tr></tbody></table>', '2017-07-03 16:27', '63500c6e5d9f304acaa1a5552e9816a7', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('136', 'Replied', 'u10', 'u11', 'Migração do domínio e email', '<p>A migração do site montpiscinas.com.br foi concluída e os emails transferidos, já pode dar início na criação do conteúdo no site.</p><p>Para acessar o site use o link direto: montpiscinas.com.br/index.php</p><p>Att</p>', '2017-07-05 21:18', '9f0a678f65680a7c1559bcab956973e9', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('137', 'Replied', 'u11', 'u10', 'Migração do domínio e email', '<p>Sensacional.</p><p>Vamos concluir agora !!! </p><p><br></p><p>Vou seguir respondendo o chamado do cliente agora.</p>', '2017-07-05 22:31', '9f0a678f65680a7c1559bcab956973e9', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('138', 'Read', 'u10', 'u11', 'Migração do domínio e email', 'Eu já respondi kkkkk', '2017-07-05 23:09', '9f0a678f65680a7c1559bcab956973e9', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('139', 'Replied', 'u10', 'u11', 'Proposta', 'Segue a proposta em anexo, veja se esta tudo correto e se precisar alterar alguma coisa me informa.', '2017-10-29 00:16', 'bf18adcfb7c09f5b1aaab7fb84f369b8', '0', 'Proposta.pdf', '9ed2ae24d0e41b6acc53bdf474dcd7e5.pdf');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('140', 'Replied', 'u10', 'u12', 'Proposta', '<span style=\"color: rgb(68, 68, 68);\">Segue a proposta em anexo, veja se esta tudo correto e se precisar alterar alguma coisa me informa.</span>', '2017-10-29 00:17', '420d7eb1d05cfc22b025a22328999e89', '0', 'Proposta.pdf', '0c3d8bd6649c376c5168f025c12ed3e6.pdf');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('141', 'Read', 'u10', 'u11', 'Proposta', 'Segue anexo com anexo atualizado', '2017-10-29 00:23', 'bf18adcfb7c09f5b1aaab7fb84f369b8', '0', 'Proposta.pdf', '027e544993fe14f5523a80734dd6af55.pdf');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('142', 'Replied', 'u10', 'u12', 'Proposta', 'Segue anexo com anexo atualizado', '2017-10-29 00:24', '420d7eb1d05cfc22b025a22328999e89', '0', 'Proposta.pdf', 'f47dbc77a7491d5b4b80d21f2e29db90.pdf');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('143', 'Read', 'u10', 'u12', 'Proposta', 'Segue anexo', '2017-10-30 10:24', '420d7eb1d05cfc22b025a22328999e89', '0', 'Proposta_WebsiteGO.pdf', '268364cee3388205248aca7f551e8856.pdf');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('144', 'Read', 'u10', 'u12', 'Orçamento Fernanda', '', '2017-11-06 11:54', 'de702ea0665248fa4326bf834d079786', '0', 'WebsiteGO.pdf', '80d74a9457fd556aed2ab419c61420fe.pdf');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('145', 'Replied', 'u14', 'u11', 'tarefas', 'Boa tarde thiago o site do Rene Muniz ainda não possui tafefas disponiveis?', '2017-12-07 15:17', '8c7bbf9b2c01be31658633f6f5e9f3b4', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('146', 'Replied', 'u11', 'u14', 'tarefas', '<p>Boa tarde !</p><p>Ainda não, estou criando agora, apesar do site está quase pronto.</p><p>renemuniz.net/novo</p><p>De toda forma vou atualizar na central as tarefas.</p>', '2017-12-07 15:21', '8c7bbf9b2c01be31658633f6f5e9f3b4', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('147', 'Read', 'u11', 'u14', 'tarefas', '<p>Corrigindo:</p><p><br></p><p>Site: http://renemuniz.net/novosite</p>', '2017-12-07 15:22', '8c7bbf9b2c01be31658633f6f5e9f3b4', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('148', 'Read', 'u11', 'u17', 'Pendência ', '<p>Olá, ainda falta você passar a sua agência e conta itaú.</p><p><br></p><p>Ficamos no aguardo.</p>', '2017-12-07 15:32', 'b0acef9eb5405c2290aa2e30a7e5099f', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('149', 'New', 'u11', 'c51', 'Pendência Cadastral ', '<p>Boa tarde Renê tudo bom ?</p><p>Estamos com uma pendência em seu cadastro que precisamos preencher.</p><p>Preciso que informe o Seu <span style=\"background-color: yellow;\">CPF</span> ou <span style=\"background-color: yellow;\">CNPJ</span>.</p><p>Ficamos no aguardo, obrigado.</p>', '2017-12-07 15:34', 'cf691d9a6125337fd8ad4e8a54195afa', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('150', 'New', 'u11', 'u12', 'Poup up jacquet', '<div>código thiago</div><div><br></div><div>&lt;center&gt;</div><div>&lt;a href=\"http://templates.profissional.ws/jacquet/wp-content/uploads/2017/12/Jacquet-Regulamento-Promocao-Achou-Ganhou-14-11-2017-rev-CEF.pdf\" target=\"_blank\" target=\"_blank\"&gt;&lt;img src=\"http://templates.profissional.ws/jacquet/wp-content/uploads/2017/12/jacquet02.jpg\" class=\"img-responsive\"&gt;&lt;/a&gt;</div><div>&lt;/center&gt;</div><div><br></div><div><br></div><div>Código kaique</div><div><br></div><div>&lt;img src=\"http://templates.profissional.ws/jacquet/wp-content/uploads/2017/12/jacquet02.jpg\" class=\"img-responsive\" /&gt;<br></div>', '2017-12-07 18:20', 'df0a187dfca386e785fc393df176177b', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('151', 'Read', 'u11', 'u10', 'Pendências Kingyo', '<p>Segue Kaique.</p><p>Horário de funcionamento.<br></p><p>Segunda a sexta <br>11:30 - 15h<br><br>Quinta e sexta <br>18h 21h<br><br>Sabado das 12h às 21h<br><br><span style=\"font-weight: bold;\">Cardápio</span><br><br><span style=\"background-color: yellow;\">sem</span> yakisoba<br><span style=\"background-color: yellow;\">sem</span> acelga<br></p>', '2017-12-08 21:19', '00a925bb69f66c466aa8b22f23276817', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('152', 'Read', 'u11', 'c30', 'Sua fatura da WebsiteGO chegou.', '<p>Prezado(a) Rafael.<br>\n</p><p>A sua fatura digital chegou fresquinha.<br></p><p>Valor de R$ <b>35,00</b> com vencimento <span style=\"font-weight: bold;\">13/12/2017</span><br>\n<br>\nCaso o pagamento já tenha sido efetuado, por favor desconsidere este aviso.<br>\n<br>\nAtenciosamente,</p>', '2017-12-08 22:27', '93a997aaf3f101d3fd731d8c6ef8c6ea', '0', 'rafaelpalma.pdf', 'a17dec7c06c7db6e4b8ee874082de7b7.pdf');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('153', 'Read', 'u11', 'c29', 'Sua fatura da WebsiteGO chegou.', '<p>Prezado(a) Rafael.<br>\n</p><p>A sua fatura digital chegou fresquinha.<br></p><p>O valor é de R$ <b>35,00</b> com vencimento para o dia <span style=\"font-weight: bold;\">13/12/2017</span><br>\n<br>\nCaso o pagamento já tenha sido efetuado, por favor desconsidere este aviso\n\n</p>', '2017-12-08 22:36', '45142198d6180884e574c958be408561', '0', 'rafaelpalma.pdf', '4a748a959db42c85c836ffedd916a16f.pdf');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('154', 'Marked', 'u11', 'c46', 'Sua fatura da WebsiteGO chegou.', '<p>Prezado(a) Vitor.<br>\n</p><p>A sua fatura digital chegou fresquinha.<br></p><p>O valor é de <span style=\"color: rgb(57, 123, 33);\"><span style=\"font-weight: bold;\">R$</span> <b>35,00</b></span> com vencimento para o dia <span style=\"color: rgb(255, 0, 0);\"><span style=\"font-weight: bold;\">13/12/2017</span></span><br>\n<br>\nCaso o pagamento já tenha sido efetuado, por favor desconsidere este aviso.\n\n</p>', '2017-12-08 23:17', '4ecd46af07b0c17c49cc38bd67c26093', '0', 'vitorleandro.pdf', '8ff83e9eaaf0197764e3548144fe82c0.pdf');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('155', 'Read', 'u11', 'u17', 'teste', '<p style=\"color: rgb(68, 68, 68);\">Prezado(a) Vitor.<br></p><p style=\"color: rgb(68, 68, 68);\">A sua fatura digital chegou fresquinha.<br></p><p style=\"color: rgb(68, 68, 68);\">O valor é de&nbsp;<span style=\"color: rgb(57, 123, 33);\"><span style=\"font-weight: bold;\">R$</span>&nbsp;<span style=\"font-weight: 700;\">35,00</span></span>&nbsp;com vencimento para o dia&nbsp;<span style=\"color: rgb(255, 0, 0);\"><span style=\"font-weight: bold;\">13/12/2017</span></span><br><br>Caso o pagamento já tenha sido efetuado, por favor desconsidere este aviso.</p>', '2017-12-11 19:47', '12e3f5c5853a095104a784bef57b47ee', '0', 'Boletos.pdf', '2b9465626bc8dedff7e0cc471639e8f5.pdf');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('156', 'New', 'u11', 'c49', 'Lembrete - Website GO ', '<p style=\"color: rgb(68, 68, 68);\">Prezado(a) Alexandre ME<br></p><p style=\"color: rgb(68, 68, 68);\">A sua fatura vence hoje&nbsp;<span style=\"color: rgb(255, 0, 0); font-weight: 700;\">22/12/2017,</span><br></p><p style=\"color: rgb(68, 68, 68);\">O valor é de&nbsp;<span style=\"color: rgb(57, 123, 33);\"><span style=\"font-weight: bold;\">R$</span>&nbsp;<span style=\"font-weight: 700;\">504,00.</span></span><br><br>Caso o pagamento já tenha sido efetuado, por favor desconsidere este aviso.</p>', '2017-12-22 11:06', '8f621cca797066e572531539cdd1f97d', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('157', 'Read', 'u10', 'u11', 'Foto', '', '2018-04-10 12:22', '36534c6d881708f2b911438805a61947', '0', '100_3749.JPG', '1b38ada75e9606e75726a5ee985e9d10.JPG');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('158', 'Replied', 'c68', 'u10', 'nfe', '<p><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">Bom dia,&nbsp;</font></font></p><p><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">Poderia nos enviar a NFE para darmos entrada no financeiro?</font></font></p><p><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">o pagamento foi realizado, ontem 01/08/2018.</font></font></font></font></p>', '2018-08-01 07:24', '0d85015e1676fca6cfdd0ce28c147c78', '0', '', '');
INSERT INTO privatemessages (`id`, `status`, `sender`, `recipient`, `subject`, `message`, `time`, `conversation`, `deleted`, `attachment`, `attachment_link`) VALUES ('159', 'Read', 'u10', 'c68', 'nfe', '<p>Bom dia Carlos</p><p>Estou encaminhando sua solicitação para o financeiro gerar a nota fiscal.</p><p>Peço que aguarde nosso retorno.</p><p>Atenciosamente</p>', '2018-08-01 08:32', '0d85015e1676fca6cfdd0ce28c147c78', '0', '', '');


#
# TABLE STRUCTURE FOR: project_has_activities
#

DROP TABLE IF EXISTS project_has_activities;

CREATE TABLE `project_has_activities` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `project_id` bigint(20) DEFAULT '0',
  `user_id` bigint(20) DEFAULT '0',
  `client_id` bigint(20) DEFAULT '0',
  `datetime` varchar(250) DEFAULT '0',
  `subject` varchar(250) DEFAULT '0',
  `message` longtext,
  `type` varchar(250) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('2', '15', '10', '0', '1497973333', 'file de mídia foi adicionado', '<b>Kaique Alves</b> carregado Template', 'media');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('3', '16', '11', '0', '1498573116', 'file de mídia foi adicionado', '<b>Thiago Pimentel</b> carregado Mídia para a criação do site - montpiscinas.com.br', 'media');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('4', '16', '11', '0', '1498656469', 'file de mídia foi adicionado', '<b>Thiago Pimentel</b> carregado Descrição dos Produtos', 'media');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('5', '19', '12', '0', '1509653615', 'file de mídia foi adicionado', '<b>Leandro  Julio</b> carregado Contrato', 'media');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('6', '16', '12', '0', '1509653676', 'file de mídia foi adicionado', '<b>Leandro  Julio</b> carregado Contrato', 'media');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('7', '19', '11', '0', '1509990373', 'file de mídia foi adicionado', '<b>Thiago Pimentel</b> carregado Contrato', 'media');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('8', '19', '11', '0', '1510171775', 'file de mídia foi adicionado', '<b>Thiago Pimentel</b> carregado ', 'media');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('9', '19', '11', '0', '1510235213', 'file de mídia foi adicionado', '<b>Thiago Pimentel</b> carregado Logo', 'media');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('10', '19', '11', '0', '1510236220', 'file de mídia foi adicionado', '<b>Thiago Pimentel</b> carregado Cardápio', 'media');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('11', '18', '11', '0', '1510236401', 'file de mídia foi adicionado', '<b>Thiago Pimentel</b> carregado Logo', 'media');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('12', '18', '11', '0', '1510236484', 'file de mídia foi adicionado', '<b>Thiago Pimentel</b> carregado acessos', 'media');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('13', '19', '11', '0', '1510252349', 'file de mídia foi adicionado', '<b>Thiago Pimentel</b> carregado Imagens', 'media');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('14', '19', '12', '0', '1513130787', 'file de mídia foi adicionado', '<b>Leandro  Julio</b> carregado ', 'media');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('15', '22', '11', '0', '1513860908', 'file de mídia foi adicionado', '<b>Thiago Pimentel</b> carregado ', 'media');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('16', '22', '12', '0', '1514315469', 'file de mídia foi adicionado', '<b>Leandro  Julio</b> carregado Contrato Renê Muniz', 'media');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('17', '22', '12', '0', '1514316371', 'file de mídia foi adicionado', '<b>Leandro  Julio</b> carregado Contrato', 'media');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('18', '25', '11', '0', '1521044990', 'file de mídia foi adicionado', '<b>Thiago Pimentel</b> carregado Boleto', 'media');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('19', '27', '17', '0', '1521045783', 'file de mídia foi adicionado', '<b>Victor Henrique Miranda Silva</b> carregado BOLETO ', 'media');
INSERT INTO project_has_activities (`id`, `project_id`, `user_id`, `client_id`, `datetime`, `subject`, `message`, `type`) VALUES ('20', '23', '0', '55', '1524170577', 'file de mídia foi adicionado', '<b>Cristiana  Oliveira Lino</b> carregado Consorcio-capa', 'media');


#
# TABLE STRUCTURE FOR: project_has_files
#

DROP TABLE IF EXISTS project_has_files;

CREATE TABLE `project_has_files` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) DEFAULT '0',
  `user_id` int(10) DEFAULT '0',
  `client_id` int(10) DEFAULT '0',
  `type` varchar(80) DEFAULT '0',
  `name` varchar(120) DEFAULT '0',
  `filename` varchar(150) DEFAULT '0',
  `description` text,
  `savename` varchar(200) DEFAULT '0',
  `phase` varchar(100) DEFAULT '0',
  `date` varchar(50) DEFAULT '0',
  `download_counter` int(10) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

INSERT INTO project_has_files (`id`, `project_id`, `user_id`, `client_id`, `type`, `name`, `filename`, `description`, `savename`, `phase`, `date`, `download_counter`) VALUES ('30', '15', '10', '0', 'application/zip', 'Template', 'templatewebsitego.zip', 'template', 'c9a1d4621f05b689d6e372689c87a104.zip', 'Planning', '2017-06-20 12:41', '1');
INSERT INTO project_has_files (`id`, `project_id`, `user_id`, `client_id`, `type`, `name`, `filename`, `description`, `savename`, `phase`, `date`, `download_counter`) VALUES ('31', '16', '11', '0', 'application/x-7z-compressed', 'Mídia para a criação do site - montpiscinas.com.br', 'IMAGEM_DOS_PRODTOS_COMPLETO.7z', 'Imagens fotos, Logos etc.', '351eaa255beddc6b83ef70428006af60.7z', ' Desenvolvimento', '2017-06-28 10:27', '3');
INSERT INTO project_has_files (`id`, `project_id`, `user_id`, `client_id`, `type`, `name`, `filename`, `description`, `savename`, `phase`, `date`, `download_counter`) VALUES ('32', '16', '11', '0', 'text/plain', 'Descrição dos Produtos', 'Descrição_de_produtos.txt', 'montpiscinas.com.br', 'e44742a25dc22947017ca42bb7bb016e.txt', ' Desenvolvimento', '2017-06-28 10:26', '4');
INSERT INTO project_has_files (`id`, `project_id`, `user_id`, `client_id`, `type`, `name`, `filename`, `description`, `savename`, `phase`, `date`, `download_counter`) VALUES ('34', '16', '12', '0', 'application/octet-stream', 'Contrato', 'Contrato_montpiscinas.docx', 'Contrato de serviço', 'a70d2c95148e94b2fda366282109f76a.docx', ' Testes finais', '2017-11-02 18:14', '0');
INSERT INTO project_has_files (`id`, `project_id`, `user_id`, `client_id`, `type`, `name`, `filename`, `description`, `savename`, `phase`, `date`, `download_counter`) VALUES ('35', '19', '11', '0', 'application/octet-stream', 'Contrato', 'contrato-kingyotemakeria.docx', 'Kingyo Temakeria', '962b7b283cfab25a1be7b15e86318ee5.docx', 'Planning', '2017-11-06 15:45', '5');
INSERT INTO project_has_files (`id`, `project_id`, `user_id`, `client_id`, `type`, `name`, `filename`, `description`, `savename`, `phase`, `date`, `download_counter`) VALUES ('36', '19', '11', '0', 'text/plain', 'Acesso FTP', 'acesso_FTP.txt', '', 'f8df9a57932c5523f1cb7427c4dfda67.txt', 'Planning', '2017-11-08 18:09', '0');
INSERT INTO project_has_files (`id`, `project_id`, `user_id`, `client_id`, `type`, `name`, `filename`, `description`, `savename`, `phase`, `date`, `download_counter`) VALUES ('37', '19', '11', '0', 'image/png', 'Logo', 'KINGYO_05.png', 'provisorio', '8306df741f91d414916d99df1ccb073a.png', 'Planning', '2017-11-09 11:46', '2');
INSERT INTO project_has_files (`id`, `project_id`, `user_id`, `client_id`, `type`, `name`, `filename`, `description`, `savename`, `phase`, `date`, `download_counter`) VALUES ('39', '18', '11', '0', 'image/png', 'Logo', 'sem_nome_(1).png', 'vb', 'b58522d3125a90b6b75e53707333f093.png', 'Planning', '2017-11-09 12:06', '0');
INSERT INTO project_has_files (`id`, `project_id`, `user_id`, `client_id`, `type`, `name`, `filename`, `description`, `savename`, `phase`, `date`, `download_counter`) VALUES ('40', '18', '11', '0', 'text/plain', 'acessos', 'dados_de_acesso.txt', 'vb', '2658607b16d7b7bb6a22716cc4bd15fc.txt', 'Planning', '2017-11-09 12:07', '1');
INSERT INTO project_has_files (`id`, `project_id`, `user_id`, `client_id`, `type`, `name`, `filename`, `description`, `savename`, `phase`, `date`, `download_counter`) VALUES ('41', '19', '11', '0', 'text/plain', 'Imagens', 'imagens-kingyo.txt', 'Kingyo', '58320d9fe5d8b8e81ae305a5a7d24a42.txt', 'Planning', '2017-11-09 16:32', '6');
INSERT INTO project_has_files (`id`, `project_id`, `user_id`, `client_id`, `type`, `name`, `filename`, `description`, `savename`, `phase`, `date`, `download_counter`) VALUES ('42', '19', '12', '0', 'image/jpeg', '', 'GEDC0940.JPG', '', 'b5e24fb2dba6602c3b6fb17e68622ba5.JPG', 'Planning', '2017-12-13 00:03', '0');
INSERT INTO project_has_files (`id`, `project_id`, `user_id`, `client_id`, `type`, `name`, `filename`, `description`, `savename`, `phase`, `date`, `download_counter`) VALUES ('45', '22', '12', '0', 'application/octet-stream', 'Contrato', 'contrato-Rene-Muniz.docx', 'Renê Muniz', 'e5532a336da3a8f1834208f670e2c626.docx', 'Planning', '2017-12-26 17:25', '3');
INSERT INTO project_has_files (`id`, `project_id`, `user_id`, `client_id`, `type`, `name`, `filename`, `description`, `savename`, `phase`, `date`, `download_counter`) VALUES ('46', '25', '11', '0', 'application/pdf', 'Boleto', 'cartão_02.pdf', 'boleto', '77ffc5540fcfec0a913a433f09956e1c.pdf', 'Planning', '2018-03-14 11:29', '1');
INSERT INTO project_has_files (`id`, `project_id`, `user_id`, `client_id`, `type`, `name`, `filename`, `description`, `savename`, `phase`, `date`, `download_counter`) VALUES ('47', '27', '17', '0', 'image/png', 'BOLETO ', '2.png', 'DSDSDS', 'ec27647a17cb25db2d5d1fd411132a99.png', 'Planning', '2018-03-14 11:42', '0');
INSERT INTO project_has_files (`id`, `project_id`, `user_id`, `client_id`, `type`, `name`, `filename`, `description`, `savename`, `phase`, `date`, `download_counter`) VALUES ('48', '23', '0', '55', 'image/jpeg', 'Consorcio-capa', 'consorcio-capa.jpg', 'imagem', '954ba19763292e31d66e2475d78d0652.jpg', ' Testing', '2018-04-19 15:41', '0');


#
# TABLE STRUCTURE FOR: project_has_invoices
#

DROP TABLE IF EXISTS project_has_invoices;

CREATE TABLE `project_has_invoices` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `project_id` bigint(20) DEFAULT '0',
  `invoice_id` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: project_has_tasks
#

DROP TABLE IF EXISTS project_has_tasks;

CREATE TABLE `project_has_tasks` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) DEFAULT '0',
  `name` varchar(250) DEFAULT '0',
  `user_id` int(10) DEFAULT '0',
  `status` varchar(50) DEFAULT '0',
  `public` int(10) DEFAULT '0',
  `datetime` int(11) DEFAULT NULL,
  `due_date` varchar(250) DEFAULT NULL,
  `description` text,
  `value` int(11) DEFAULT '0',
  `priority` smallint(6) DEFAULT '0',
  `time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: project_has_workers
#

DROP TABLE IF EXISTS project_has_workers;

CREATE TABLE `project_has_workers` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8;

INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('41', '11', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('42', '12', '15');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('43', '11', '11');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('44', '11', '12');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('45', '11', '14');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('46', '13', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('47', '14', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('49', '14', '11');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('50', '14', '14');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('51', '14', '16');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('52', '15', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('53', '15', '11');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('55', '16', '11');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('56', '16', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('57', '16', '12');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('58', '16', '14');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('59', '16', '17');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('60', '15', '14');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('61', '17', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('62', '18', '11');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('63', '19', '11');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('64', '20', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('65', '19', '12');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('66', '19', '14');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('67', '19', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('68', '18', '14');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('69', '21', '11');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('70', '21', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('71', '22', '11');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('72', '18', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('73', '18', '12');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('74', '22', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('75', '22', '12');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('76', '22', '14');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('77', '21', '14');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('78', '23', '11');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('79', '23', '10');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('80', '23', '12');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('81', '23', '14');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('82', '24', '11');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('83', '24', '14');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('84', '25', '11');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('85', '26', '17');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('86', '27', '17');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('87', '28', '11');
INSERT INTO project_has_workers (`id`, `project_id`, `user_id`) VALUES ('88', '29', '11');


#
# TABLE STRUCTURE FOR: projects
#

DROP TABLE IF EXISTS projects;

CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` int(11) DEFAULT NULL,
  `name` varchar(65) DEFAULT NULL,
  `description` text,
  `start` varchar(20) DEFAULT NULL,
  `end` varchar(20) DEFAULT NULL,
  `progress` decimal(3,0) DEFAULT NULL,
  `phases` varchar(150) DEFAULT NULL,
  `tracking` int(11) DEFAULT NULL,
  `time_spent` int(11) DEFAULT NULL,
  `datetime` int(11) DEFAULT NULL,
  `sticky` enum('1','0') DEFAULT '0',
  `category` varchar(150) DEFAULT NULL,
  `company_id` int(11) NOT NULL,
  `note` longtext NOT NULL,
  `progress_calc` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_projects_clients1` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: pw_reset
#

DROP TABLE IF EXISTS pw_reset;

CREATE TABLE `pw_reset` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `email` varchar(250) DEFAULT '0',
  `timestamp` varchar(250) DEFAULT '0',
  `token` varchar(250) DEFAULT '0',
  `user` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO pw_reset (`id`, `email`, `timestamp`, `token`, `user`) VALUES ('2', 'gerson.nascimento@locaweb.com.br', '1503010413', '2652009a03fe87c77564b461024c6c92', '0');
INSERT INTO pw_reset (`id`, `email`, `timestamp`, `token`, `user`) VALUES ('3', 'gerson.nascimento@locaweb.com.br', '1503010953', 'ef3d6cdee3fe56dc631ed09e8d264df7', '0');
INSERT INTO pw_reset (`id`, `email`, `timestamp`, `token`, `user`) VALUES ('4', 'gerson.nascimento@locaweb.com.br', '1504628374', '02bc75a5440d9e45b192b71276852233', '0');
INSERT INTO pw_reset (`id`, `email`, `timestamp`, `token`, `user`) VALUES ('5', 'valdohardware@hotmail.com', '1534443815', '2727330df5555e1bee88cd89b906eb12', '0');
INSERT INTO pw_reset (`id`, `email`, `timestamp`, `token`, `user`) VALUES ('6', 'ezequiassoares@hotmail.com', '1536074608', 'b425ad5a6aff8185cf84d17db3d14c86', '0');


#
# TABLE STRUCTURE FOR: queues
#

DROP TABLE IF EXISTS queues;

CREATE TABLE `queues` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT '0',
  `description` varchar(250) DEFAULT '0',
  `inactive` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO queues (`id`, `name`, `description`, `inactive`) VALUES ('1', 'Suporte', 'Suporte técnico', '0');
INSERT INTO queues (`id`, `name`, `description`, `inactive`) VALUES ('2', 'Vendas', 'Vendas', '0');
INSERT INTO queues (`id`, `name`, `description`, `inactive`) VALUES ('3', 'Cobrança', 'cobrança', '0');


#
# TABLE STRUCTURE FOR: quotations
#

DROP TABLE IF EXISTS quotations;

CREATE TABLE `quotations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `q1` varchar(50) DEFAULT NULL,
  `q2` varchar(50) DEFAULT NULL,
  `q3` varchar(50) DEFAULT NULL,
  `q4` varchar(150) DEFAULT NULL,
  `q5` text,
  `q6` varchar(50) DEFAULT NULL,
  `company` varchar(150) DEFAULT '-',
  `fullname` varchar(150) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(150) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `city` varchar(150) DEFAULT NULL,
  `zip` varchar(150) DEFAULT NULL,
  `country` varchar(150) DEFAULT NULL,
  `comment` text,
  `date` varchar(50) DEFAULT NULL,
  `status` varchar(150) DEFAULT '0',
  `user_id` int(50) DEFAULT '0',
  `replied` varchar(50) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: subscription_has_items
#

DROP TABLE IF EXISTS subscription_has_items;

CREATE TABLE `subscription_has_items` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `subscription_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `amount` char(11) DEFAULT NULL,
  `description` mediumtext,
  `value` float DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `type` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

INSERT INTO subscription_has_items (`id`, `subscription_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('1', '13', '0', '1', '', '35', 'Hospedagem Basic - MySQL incluso - 5 Caixas postais', '');
INSERT INTO subscription_has_items (`id`, `subscription_id`, `item_id`, `amount`, `description`, `value`, `name`, `type`) VALUES ('2', '13', '0', '1', '', '100', 'Desenvolvimento de sites', '');


#
# TABLE STRUCTURE FOR: subscriptions
#

DROP TABLE IF EXISTS subscriptions;

CREATE TABLE `subscriptions` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `reference` varchar(50) DEFAULT NULL,
  `company_id` int(10) DEFAULT '0',
  `status` varchar(50) DEFAULT NULL,
  `currency` varchar(20) DEFAULT NULL,
  `issue_date` varchar(20) DEFAULT NULL,
  `end_date` varchar(20) DEFAULT NULL,
  `frequency` varchar(20) DEFAULT NULL,
  `next_payment` varchar(20) DEFAULT NULL,
  `terms` mediumtext,
  `discount` varchar(50) DEFAULT '0',
  `subscribed` varchar(50) DEFAULT '0',
  `tax` varchar(255) DEFAULT '',
  `second_tax` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO subscriptions (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `end_date`, `frequency`, `next_payment`, `terms`, `discount`, `subscribed`, `tax`, `second_tax`) VALUES ('11', '61001', '28', 'Active', 'R$ 40,00', '2018-04-15', '2020-04-15', '+1 year', '2018-04-15', 'Thank you for your business. We do expect payment within {due_date}, so please process this invoice within that time.', '', '0', '0', '');
INSERT INTO subscriptions (`id`, `reference`, `company_id`, `status`, `currency`, `issue_date`, `end_date`, `frequency`, `next_payment`, `terms`, `discount`, `subscribed`, `tax`, `second_tax`) VALUES ('13', '61003', '26', 'Active', 'R$', '2017-12-10', '2018-12-10', '+1 month', '2017-12-10', '<div><div>Agradecemos por escolher a WebsiteGo. Mantenha o pagamento em dia e evite a suspensão parcial/total dos seus projetos.</div></div><div><br></div><div>Vencimento:<span style=\"color: rgb(33, 33, 33); font-family: arial, sans-serif; font-size: 16px; white-space: pre-wrap;\">{due_date}.</span></div>', '', '0', '0', '');


#
# TABLE STRUCTURE FOR: templates
#

DROP TABLE IF EXISTS templates;

CREATE TABLE `templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(250) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `text` text NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ticket_has_articles
#

DROP TABLE IF EXISTS ticket_has_articles;

CREATE TABLE `ticket_has_articles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) DEFAULT NULL,
  `from` varchar(250) NOT NULL DEFAULT '0',
  `reply_to` varchar(250) DEFAULT '0',
  `to` varchar(250) DEFAULT '0',
  `cc` varchar(250) DEFAULT '0',
  `subject` varchar(250) DEFAULT '0',
  `message` text,
  `datetime` varchar(250) DEFAULT NULL,
  `internal` int(10) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8;

INSERT INTO ticket_has_articles (`id`, `ticket_id`, `from`, `reply_to`, `to`, `cc`, `subject`, `message`, `datetime`, `internal`) VALUES ('120', '52', 'Kaique Alves - kaiqueexp@gmail.com', 'kaiqueexp@gmail.com', 'teste@teste.com.br', '0', 'Fechar', 'teste', '1497641858', '0');
INSERT INTO ticket_has_articles (`id`, `ticket_id`, `from`, `reply_to`, `to`, `cc`, `subject`, `message`, `datetime`, `internal`) VALUES ('121', '52', 'teste teste - teste@teste.com.br', 'teste@teste.com.br', '0', '0', 'Nota 10', '10', '1497641883', '0');
INSERT INTO ticket_has_articles (`id`, `ticket_id`, `from`, `reply_to`, `to`, `cc`, `subject`, `message`, `datetime`, `internal`) VALUES ('122', '54', 'Thiago Pimentel - thiagopimentel@terra.com.br', 'thiagopimentel@terra.com.br', 'bitencourt.palma@hotmail.com', '0', 'Migração de Plataforma - montpiscinas.com.br', '<span style=\"color: rgb(68, 68, 68);\">Bom dia Rafael.</span><div><span style=\"color: rgb(68, 68, 68);\"><br></span></div><div><span style=\"color: rgb(68, 68, 68);\">A migração foi adiada por enquanto sem previsão de retorno.</span></div><div><span style=\"color: rgb(68, 68, 68);\"><br></span></div><div><span style=\"color: rgb(68, 68, 68);\">Pode seguir usando os e-mails normalmente.</span></div><div><span style=\"color: rgb(68, 68, 68);\"><br></span></div><div><span style=\"color: rgb(68, 68, 68);\">Qualquer novo update notificaremos neste protocolo.</span></div><div><span style=\"color: rgb(68, 68, 68);\"><br></span></div><div><p style=\"margin-bottom: 1em; color: rgb(68, 68, 68);\">Att.</p><p style=\"margin-bottom: 1em; color: rgb(68, 68, 68);\">WebsiteGO</p></div>', '1498576150', '0');
INSERT INTO ticket_has_articles (`id`, `ticket_id`, `from`, `reply_to`, `to`, `cc`, `subject`, `message`, `datetime`, `internal`) VALUES ('123', '54', 'Kaique Alves - kaiqueexp@gmail.com', 'kaiqueexp@gmail.com', 'bitencourt.palma@hotmail.com', '0', 'Migração de Plataforma - montpiscinas.com.br', 'Boa noite Rafael,<div><br></div><div>Realizamos a migração de seu site para a plataforma linux e todos os seus emails também foram migrados.</div><div><br></div><div>Informo que a migração já foi concluída e você já poderá utilizar os emails normalmente.</div><div><br></div><div>Atenciosamente</div><div><br></div><div>Websitego</div>', '1499300106', '0');


#
# TABLE STRUCTURE FOR: ticket_has_attachments
#

DROP TABLE IF EXISTS ticket_has_attachments;

CREATE TABLE `ticket_has_attachments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint(20) DEFAULT '0',
  `filename` varchar(250) DEFAULT '0',
  `savename` varchar(250) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: tickets
#

DROP TABLE IF EXISTS tickets;

CREATE TABLE `tickets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `from` varchar(250) DEFAULT '0',
  `reference` varchar(250) DEFAULT '0',
  `type_id` smallint(6) DEFAULT '1',
  `lock` smallint(6) DEFAULT '0',
  `subject` varchar(250) DEFAULT '0',
  `text` text,
  `status` varchar(50) DEFAULT '0',
  `client_id` int(11) DEFAULT '0',
  `company_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `escalation_time` int(11) DEFAULT '0',
  `priority` varchar(50) DEFAULT '0',
  `created` int(11) DEFAULT '0',
  `queue_id` int(11) DEFAULT '0',
  `updated` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;

INSERT INTO tickets (`id`, `from`, `reference`, `type_id`, `lock`, `subject`, `text`, `status`, `client_id`, `company_id`, `user_id`, `escalation_time`, `priority`, `created`, `queue_id`, `updated`) VALUES ('52', 'teste teste - teste@teste.com.br', '10000', '1', '0', 'teste', 'teste', 'closed', '34', '32', '11', '0', '0', '1497641778', '1', '1');
INSERT INTO tickets (`id`, `from`, `reference`, `type_id`, `lock`, `subject`, `text`, `status`, `client_id`, `company_id`, `user_id`, `escalation_time`, `priority`, `created`, `queue_id`, `updated`) VALUES ('53', 'teste kaique testeq - kaiquesp@hotmail.com', '10001', '1', '0', 'teste #01', 'teste', 'closed', '39', '37', '11', '0', '0', '1498074860', '1', '0');
INSERT INTO tickets (`id`, `from`, `reference`, `type_id`, `lock`, `subject`, `text`, `status`, `client_id`, `company_id`, `user_id`, `escalation_time`, `priority`, `created`, `queue_id`, `updated`) VALUES ('54', 'Rafael  Bitencourt Palma - bitencourt.palma@hotmail.com', '10002', '1', '0', 'Migração de Plataforma - montpiscinas.com.br', '<p style=\"margin-bottom: 1em;\">Bom dia Rafael.</p><p style=\"margin-bottom: 1em;\">A migração de Plataforma da sua Hospedagem está agendada para as 11:30&nbsp;</p><p style=\"margin-bottom: 1em;\">Com previsão para a correção até as 13:30</p><p style=\"margin-bottom: 1em;\">Qualquer novo update notificaremos neste protocolo.</p><p style=\"margin-bottom: 1em;\">Att.</p><p style=\"margin-bottom: 1em;\">WebsiteGO</p>', 'closed', '29', '26', '11', '0', '0', '1498571886', '1', '0');


#
# TABLE STRUCTURE FOR: types
#

DROP TABLE IF EXISTS types;

CREATE TABLE `types` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT '0',
  `description` varchar(250) DEFAULT '0',
  `inactive` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

INSERT INTO types (`id`, `name`, `description`, `inactive`) VALUES ('1', 'Requisiçao de serviço', 'Requisiçao de serviço', '0');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) DEFAULT NULL,
  `firstname` varchar(120) DEFAULT NULL,
  `lastname` varchar(120) DEFAULT NULL,
  `hashed_password` varchar(128) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `status` enum('active','inactive','deleted') DEFAULT NULL,
  `admin` enum('0','1') DEFAULT NULL,
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `userpic` varchar(250) DEFAULT 'no-pic.png',
  `title` varchar(150) NOT NULL,
  `access` varchar(150) NOT NULL DEFAULT '1,2',
  `last_active` varchar(50) DEFAULT NULL,
  `last_login` varchar(50) DEFAULT NULL,
  `queue` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('9', 'Admin', 'John', 'Doe', '785ea3511702420413df674029fe58d69692b3a0a571c0ba30177c7808db69ea22a8596b1cc5777403d4374dafaa708445a9926d6ead9a262e37cb0d78db1fe5', 'local@localhost', 'deleted', '1', '2013-01-01 00:00:00', 'no-pic.png', 'Administrator', '1,2,3,4,5,8,6,7,9,10,11,16,18,19', '1497889854', '1497475741', '0');
INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('10', 'kaique.alves', 'Kaique', 'Alves', '2de0452b2643fbe9e2ade14f51da5d000e06da7d49d63321b9ceae6ad60a085c86b8c70388a30199fa1303cac7b5e2357528f4584bc20a3401501dc4e279b433', 'kaiqueexp@gmail.com', 'active', '1', '2017-06-14 18:54:20', 'no-pic.png', 'Administrador', '1,2,3,4,5,18,19,8,6,7,16,9,10,11', '0', '1534950796', '0');
INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('11', 'thiago.pimentel', 'Thiago', 'Pimentel', '5c139c4b386804851ace7d415003d036e4d69eeb51cf4885569b443eb64cd516903cf1b9682a291eba73b9ea8141a4487994fb1aa0f2e6a9226daf97366fa4bb', 'thiagopimentel@terra.com.br', 'active', '1', '2017-06-14 20:59:28', '26ec99f64275588cad0e702fca6ce0d4.jpg', 'Gerente', '1,2,3,4,5,18,19,8,6,7,16,9,10,11', '1539095390', '1539095340', '0');
INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('12', 'leandro.julio', 'Leandro ', 'Julio', '36df42151fcb13359f29ce6c0cfdd3dc61c0221afb4745928deea1f41aa7e210ab1eb75bf9e40698029559cf80f37e441b1fb97680ac00734a8fe25f13e8b397', 'lecoideias@outlook.com', 'active', '0', '2017-06-14 21:00:17', 'no-pic.png', 'Gerente', '1,2,3,4,5,18,19,8,6,7,16,10,11', '1538396936', '1538396923', '0');
INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('14', 'dinho.braga', 'Erlandsson', 'Braga', 'd577cfc490cc93173c7733e71ecd9d876a6417705718ef8135dfed100f1f016995b4a5c83e8bcbe6e1e6ac1785eaf4965cad87d46d05cfb99312395d22fd7810', 'dinhobragacosta@gmail.com', 'active', '0', '2017-06-15 14:32:29', 'no-pic.png', 'Usuario', '1,2,3,4,18,6,7,16,10,11', '1518037208', '1518035069', '0');
INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('16', 'mayara.rodrigues', 'Mayara', 'Rodrigues', 'eb2c3a3d61dc16d8518a1a238ad88934f39541acf2813b8347a748e6c8fe63d6ad42a788bf0b2ee7210506c9d035e463a9c82322a23398d8233c431b5c584d6b', 'ma_prodrigues@hotmail.com', 'deleted', '0', '2017-06-19 21:38:13', 'no-pic.png', 'Usuario', '1,2,3,4,5,18,19,8,6,7,16,10,11', NULL, NULL, '0');
INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('17', 'victor.henrique', 'Victor', 'Henrique Miranda Silva', '3704a80d4ef5bae2e8e970dbc98d087d539645397b0eb93206ace595ff4eceb850e1d97b5e9b84b76185796e09d7c99c2734c662139a53dd6eb0571f331a3e22', 'victor@websitego.com.br', 'deleted', '1', '2017-06-20 12:58:24', 'no-pic.png', 'Usuário', '3,4,10,11', '0', '1521045633', '0');
INSERT INTO users (`id`, `username`, `firstname`, `lastname`, `hashed_password`, `email`, `status`, `admin`, `created`, `userpic`, `title`, `access`, `last_active`, `last_login`, `queue`) VALUES ('18', 'websitego', 'WebsiteGO', '.com.br', '11cd06ed62cbc4ac2c53a63e0032ef81ec362680dc378974420ff4482c22e586135169e4ccb661ff754f9aff088cd72302804b5ed771d284b8f419ea731918fa', 'suporte@websitego.com.br', 'deleted', '0', '2018-07-21 15:25:32', 'no-pic.png', 'WebsiteGO', '3', '0', '1532200089', '0');


